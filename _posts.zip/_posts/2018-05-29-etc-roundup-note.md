---
layout: post
title:  比特派暂停 ETC 相关充提及收发业务
author: 
lang: zh
data: 2018-05-29
post_id: 33
id: 33
ref: ad
time: 
---

尊敬的用户：


根据 ETC 官方消息，ETC 将在区块链高度5,900,000 进行硬分叉。本次硬分叉主要更新为移除难度炸弹，并不会产生新币。


为保证用户资产安全，比特派将暂停派银行中 ETC 充提及派钱包中 ETC 收发服务。待 ETC 硬分叉稳定后，我们将会第一时间恢复其充提及收发业务，具体时间请您及时关注公告。为此造成的不便，敬请谅解！

ETC官方公告：<a href="https://ethereumclassic.github.io/blog/2018-03-12-etc-roundup/" target="_blank" style="color:red">点击</a>


比特派团队<br/>
2018年05月29日
