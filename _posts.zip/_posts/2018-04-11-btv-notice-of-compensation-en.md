---
layout: post
title: Notice of Compensation
author: 
lang: en
data: 2018-04-11
post_id: 20
id: 20
ref: ad
time: 
---



Dear users,<br/>
This letter is to announce that the compensations to those users who suffered the loss of miner fees due to replay attack issue of BTV have been paid. 

Background：<br/>
On Feb. 7th, 2018, it’s noted that the “replay attack” protection encountered some uncertain problems. To protect the safety of the users’ assets, Bitpie stopped the BTV transfer(send/receive) service in no time and reminded BTV users to transfer their BTC into a new address. 

To date, BTV team has settled this issue, and Bitpie has resumed the transfer(send/receive) service of BTV.

Since the miner fees of BTC transferring borne by the users are extra costs, now, through negotiating between Bitpie and BTV team, BTV team agreed to compensate those users who bore such extra miner fees in the process of BTC transferring. The reimbursements have already been sent to the relevant users’ accounts in the form of BTV coins.

Your understanding and support are highly appreciated.

P.S. BTV/BTC trading pair has launched in Ex Pie!

Bitpie.com<br/>
April 12, 2018