---
layout: post
title:  Bitpie will Suspend EOS Deposit and Withdrawals and its Sending and Receiving Services at 24:00 on June 1st 2018(GMT+8) for EOS Mainnet Switch
lang: en
data: 2018-05-30
post_id: 35
id: 35
ref: ad
time: 
---


Dear Bitpiers:


EOS will stop mapping at 06:59:59 on June 2nd, 2018(GMT+8) and then take a snapshot. After that all EOS tokens based on Ethereum ERC20 will be frozen and not able to be transferred. To ensure that Bitpie users can take a snapshot and get their assets on the EOS Main Net, Bitpie will suspend EOS deposit and withdrawals and its sending and receiving services at 24:00 on June 1st 2018(GMT+8). We will resume the deposit and withdrawal promptly after the EOS Mainnet runs stably. Please pay attention to our announcement for the specific time. Your support for Bitpie is greatly appreciated!


ExPie Exchange and OTC services are not affected and will continue as normal.


Bitpie suggests EOS holders to avoid EOS trading before the EOS Mainnet mapping stopped. At the same time, before the EOS mapping stopped, if you have EOS in the Pie wallet, please make sure you have already done the mapping (<a href="http://docs.bitpie.com/en/latest/commonContract/index.html" target="_blank" style="color:red">click</a>), otherwise your assets may face the risk of losing all of you assets. You can also send your EOS to Pie Bank before 1st June(GMT+8). Pie Bank has already finished EOS mapping. Pie Bank can help you get the EOS in the Mainnet and all sorts of giveaways. Bitpie works for providing the best mapping services for you.



Bitpie Team<br/>
30th May, 2018



Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>

