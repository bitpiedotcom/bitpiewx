---
layout: post
title: Pie Bank Has Delivered ADD, CHL, IQ, EOX, HORUS, BLACK, EDNA Airdrops
author: 
lang: zh
data: 2018-08-15
post_id: 54
id: 54
ref: ad
time: 
---

Dear Bitpiers:

Pie Bank of Bitpie Wallet has already delivered ADD, CHL, IQ, EOX, HORUS, BLACK, EDNA Airdrops based on EOS mainnet to EOS holders.

Here are the detailed information.

<table class="table table-content" border="0" cellspacing="0" cellpadding="0">
<tr><th>Name of token </th><th>Snapshot date</th><th>Receivable</th><th> Airdrop supply</th><th>Total supply</th><th>Official website
</th></tr>
<tr><td>IQ</td><td>the Genesis Block</td> <td> 5.1IQ:1EOS </td><td>51billion</td><td> 100billion </td><td><a href="https://everipedia.org/" target="_blank">https://everipedia.org/</a></td></tr> 
<tr><td>ADD</td><td>the Genesis Block</td> <td> 0.5ADD:1EOS </td><td>5billion</td><td> 100billion </td><td><a href="https://eosadd.com/" target="_blank">https://eosadd.com/</a></td></tr> 
<tr><td>EOX</td><td>the Genesis Block</td> <td> 1EOX:1EOS </td><td>9billion</td><td> 100billion </td><td><a href="https://www.eoxlab.io/" target="_blank">https://www.eoxlab.io</a></td></tr>
<tr><td>HORUS</td><td>the Genesis Block</td> <td> 1HORUS:1EOS </td><td>9billion</td><td> 12billion </td><td><a href="http://www.horuspay.io" target="_blank">http://www.horuspay.io</a></td></tr>
<tr><td>CHL</td><td>the Genesis Block</td> <td> 2CHL:1EOS </td><td>20billion</td><td> 27billion </td><td><a href="http://challengedapp.io/" target="_blank">http://challengedapp.io/</a></td></tr>
<tr><td>BLACK</td><td>the Genesis Block</td> <td>1BLACK:1EOS </td><td>9billion</td><td> 30billion </td><td><a href="https://eosblack.io/" target="_blank">https://eosblack.io/</a></td></tr>
<tr><td>EDNA</td><td>the Genesis Block</td> <td>1EDNA:1EOS </td><td>10billion</td><td> 13billion </td><td><a href="https://edna.life/" target="_blank">https://edna.life/</a></td></tr>
<tr><td colspan="6">Note: the time for the Genesis Block is 7:00 am, June 3, 2018 (UTC+8).
</td></tr>
</table>

Notice: This announcement only lists the basic information of projects for your reference. It doesn’t represent official opinions of Bitpie Team or provide any investment suggestions.

Thanks a lot for your support. Bitpie will provide more premium service for you as always.


Bitpie Team<br/>
August 15, 2018

Find us on<br/>
Telegram:<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter:<a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>

<style>
.content-p{
width:70%;
}
@media(max-width:768px){
.content-p{
overflow-x:auto;
}
.table-content{
    width:700px;
}
}
</style>

