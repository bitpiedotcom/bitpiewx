---
layout: post
title:  为配合 EOS 进行主网映射，比特派将于香港时间2018年6月1日晚24点暂停 EOS 相关充提及收发业务
author: 
lang: zh
data: 2018-05-30
post_id: 35
id: 35
ref: ad
time: 
---


尊敬的比特派用户：


EOS将在香港时间2018年6月2日06点59分59秒停止映射，并会进行快照，之后所有基于以太坊的ERC20的 EOS TOKEN 将会冻结，无法转账。为确保持有 EOS 的比特派用户能正常进行快照，获得 EOS 主网资产，比特派将在香港时间2018年6月1日24点暂停派银行中 EOS 充提及派钱包中 EOS 收发服务。待 EOS 上线主网并稳定后，我们将在第一时间恢复其充提及收发业务，具体时间请您及时关注公告。为此造成的不便，敬请谅解！


届时 ExPie 交易所及点对点服务不受影响，可正常交易。


比特派建议持有 EOS 用户，在 EOS 主网停止映射前尽量避免 EOS 收发操作。同时，在 EOS 停止映射前，如果您的 EOS 在派钱包内，请您务必进行映射（映射教程：<a href="http://docs.bitpie.com/zh_CN/latest/commonContract/index.html#eos-register" target="_blank" style="color:red">请点击</a>），否则您的 EOS 资产可能会有“归零”的风险。您也可以在6月1日前将您的 EOS 存入派银行，派银行已完成 EOS 映射，同时派银行也会为 eosDAC 用户完成主网映射，时间节点相同。比特派派银行不仅可帮您领取主网的 EOS ，还可帮您领取各种空投糖果。比特派全力为您提供最妥善的映射服务！


比特派团队<br/>
2018年05月30日


Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>
