---
layout: post
title: Bitpie Wallet Starts Supporting TRON Mainnet
author: 
lang: en
data: 2018-07-09
post_id: 44
id: 44
ref: ad
time: 
---

Fellow Bitpiers:

Bitpie has already finished TRON mainnet upgrade and supported TRON mainnet. The sending and receiving services for TRX token has also been opened which means Bitpiers can henceforth send and receive TRX via Bitpie.

<img src="/img/bitpie_tron.jpg" class="tron"/>

Bitpie and TRON have announced comprehensive strategic cooperation in May and the two parties will conduct deep cooperation in various aspects. As the first mainstream cryptocurrency wallet which supports TRON mainnet, Bitpie will continue to vigorously support TRON ecology and try our best to enable the TRX holders to enjoy all-round functions and services in the first place. Bitpie will also gradually develop other services for TRON mainnet and support premium DAPPs based on TRON. Stay tuned for more functions and services!

Learn more:<a href="https://tron.network/" target="_blank">tron.network</a> <br/>
Thanks for your support!

Bitpie Team<br/>
July 9, 2018


<style>
 .tron{
    width:70%;
    display:block;
    margin:0 auto;
 }
</style>

