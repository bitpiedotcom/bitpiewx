---
layout: post
title: BTG/BTC Exchange Lucky Draw Has Now Concluded
author: 
lang: en
data: 2017-12-19
post_id: 7
id: 7
ref: ad
time: 
---

Dear Bitpie users, the BTG/BTC exchange lucky draw has now concluded. 


Below are winner lists of each group:


<p style="text-align:center;color:#3ECFAF"><strong>Top Price-- highest trading volume user（3 BTG）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0" style="text-align:center">
<tr><th>User ID</th><th>User name</th><th>Phone</th><th>trading valume</th></tr>
<tr><td>202001 </td><td>noname-376398456680</td> <td>091****8626</td><td>580.00</td></tr> 
</table>


<p style="text-align:center;color:#3ECFAF"><strong>10 - 50 BTG trading volume winners（1 BTG each）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>User name</th><th>Phone</th></tr>
<tr><td>138649</td><td>noname-280608344439</td> <td>189****7277</td></tr> 
<tr><td>159452</td><td>noname-921489879966</td><td>***********</td></tr>
<tr><td>121276</td><td>zzproxyss</td><td>138****6464</td></tr>
<tr><td>144452</td><td>laohua</td><td>189****0555</td></tr>
<tr><td>114682</td><td>xuhaif</td><td>139****5761</td></tr>
</table>
                              


<p style="text-align:center;color:#3ECFAF"><strong>1 - 10 BTG trading volume winners（0.25 BTG each）</strong></p>
<table class="table" border="0" cellspacing="0" cellpadding="0">

<tr><th>User ID</th><th>User name</th><th>Phone</th></tr>
<tr><td>174901</td><td>noname-267600409186</td><td>159****5666</td></tr>
<tr><td>132022</td><td>lamdeng14</td><td>138****4663</td></tr>
<tr><td>201521</td><td>wuxin555</td><td>177****8283</td></tr> 
<tr><td>157521</td><td>twoapples</td><td>136****5752</td></tr>
<tr><td>167449</td><td>woxinfeiyang</td><td>156****2322</td></tr>
<tr><td>103781</td><td>btcwin</td><td>136****6280</td></tr>
<tr><td>150531</td><td>wy-20171010</td><td>153****8027</td></tr>
<tr><td>105425</td><td>noname-251861544547</td><td>186****6480</td></tr>
<tr><td>196555</td><td>yusufy</td><td>138****9077</td></tr>
<tr><td>144889</td><td>zhongxun</td><td>137****2999</td></tr>
<tr><td>151032</td><td>guoyong1978</td><td>135****3768</td></tr>
<tr><td>195176</td><td>CaaKen</td><td>152****3922</td></tr>
<tr><td>148718</td><td>noname-799338700004</td><td>153****2951</td></tr> 
<tr><td>118256</td><td>hangqiao168</td><td>159****9737</td></tr>
<tr><td>182439</td><td>noname-069481413570</td><td>138****1930</td></tr>
<tr><td>121083</td><td>suwanrong</td><td>185****8166</td></tr>
<tr><td>149833</td><td>noname-643896173891</td><td>130****5698</td></tr>
<tr><td>127517</td><td>sl</td><td>180****9966</td></tr>
<tr><td>143173</td><td>cucjason</td><td>186****8115</td></tr>
<tr><td>186639</td><td>Nicole-525</td><td>150****2098</td></tr>
</table>



<p style="color:#F46100">Award BTG will be sent to your PieBank within 24 hours and you are free to withdraw the balance to your wallet anytime.</p>

<p style="color:#F46100">Congratulations to all the winners and thanks for your support!</p>

Bitpie team

Twitter:<a href="https://twitter.com/BitpieWallet" target="_blank">https://twitter.com/BitpieWallet</a>

Facebook:<a href="https://www.facebook.com/BitpieWallet" target="_blank">https://www.facebook.com/BitpieWallet</a>




