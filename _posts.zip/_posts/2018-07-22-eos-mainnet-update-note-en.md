---
layout: post
title:  Notice of EOS Block Synchronization and Upgrading 
author: 
lang: en
data: 2018-07-22
post_id: 46
id: 46
ref: ad
time: 
---

Dear Bitpiers,

The Bitpie Wallet is having EOS block synchronization and upgrading now. Though there is  abnormal display in some Bitpier’ EOS amount, the assets safety won’t be affected. The block synchronization is estimated to be finished within 24 hours.

Thanks a lot for your understanding and support. 

Bitpie Team<br/>
July 22, 2018


Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>
