---
layout: post
title:  关于 BTG 暂停充提的公告
author: 
lang: zh
data: 2018-06-30
post_id: 42
id: 42
ref: ad
time: 
---

亲爱的派友：

由于 BTG 主网升级，为了保证平台用户利益，比特派将于2018年6月30日13:00(香港时间)暂停派钱包和派银行中 BTG 的充提，并将于后续主网升级完成且运行稳定后，重新开放 BTG 充提功能。具体时间请关注后续通知。

请注意，充提服务暂停期间：<span style="color:red">请不要进行 BTG 的收发，以免造成不必要的资产损失！</span>

感谢您对比特派 Bitpie 的支持，不便之处，敬请谅解。

比特派团队<br/>
2018年06月30日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>


