---
layout: post
title:  派钱包已经支持波场 TRON 主网
author: 
lang: zh
data: 2018-07-09
post_id: 44
id: 44
ref: ad
time: 
---

亲爱的派友：

目前，比特派 Bitpie 已经完成对波场 TRON 的主网更新和支持。主网代币 TRX 的收发功能已经开启，用户即日起可以使用派钱包收发 TRX。

<img src="/img/bitpie_tron.jpg" class="tron"/>

比特派 Bitpie 与波场 TRON 已于 5 月份宣布全生态战略合作，双方将在多方面展开深度合作。作为第一款支持波场 TRON 主网的主流数字资产钱包，比特派将会一如既往地对波场 TRON 生态予以大力支持，努力让波场用户第一时间享受波场的全方位功能和服务。今后派钱包还将陆续开发针对波场主网的各项其他服务，同时也会对基于波场生态的优秀 DAPP 进行支持。更多功能敬请期待！

波场 TRON 官网： <a href="https://tron.network/" target="_blank">tron.network</a> 了解更多信息！<br/>
感谢您对比特派 Bitpie 的支持！

比特派团队<br/>
2018年07月09日


<style>
 .tron{
    width:70%;
    display:block;
    margin:0 auto;
 }
</style>