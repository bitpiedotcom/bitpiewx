---
layout: post
title:  ADD/EOS 交易大赛圆满结束
author: 
lang: zh
data: 2018-08-20
post_id: 53
id: 53
ref: ad
time: 
---

亲爱的派友：

2018 年 8 月 8 日 16:00， 比特派 Bitpie 正式开通 ADD/EOS 交易对，为感谢平台用户的支持和信任，比特派 Bitpie 连同 ADD 同步上线交易大赛以及三重奖励，花样送好礼。目前 ADD/EOS 交易大赛已圆满结束。感谢广大派友的支持和参与。

本次交易大赛公告详情请：<a href="https://bitpie.com/2018-08-06/addeos-trading-competition-note
" target="_blank">点击</a>

本次交易大赛得奖名单：<br/>
第一期：<a href="https://bitpie.com/2018-08-10/addeos-trading-competition-winner" target="_blank">点击</a><br/>
第二期：<a href="https://bitpie.com/2018-08-11/addeos-trading-competition-winner" target="_blank">点击</a><br/>
第三期：<a href="https://bitpie.com/2018-08-12/addeos-trading-competition-winner" target="_blank">点击</a><br/>
第四期：<a href="https://bitpie.com/2018-08-13/addeos-trading-competition-winner" target="_blank">点击</a><br/>
第五期：<a href="https://bitpie.com/2018-08-19/addeos-trading-competition-winner" target="_blank">点击</a><br/>



比特派团队<br/>
2018年08月20日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>

