---
layout: post
title: 关于比特派海外苹果 App Store 版更新完成的公告
author: 
lang: zh
data: 2018-04-17
post_id: 22
id: 22
ref: ad
time: 
---

因苹果对国内数字货币行业不够友好和政策限制问题，3个月前，苹果公司对 App Store 版本 Bitpie 展开漫长的问询工作，比特派期间一直在配合苹果公司进行相关资料的提供。3月22日，比特派 iOS 企业证书版因苹果公司的限制无法正常使用。苹果的政策导致 iOS 端的用户只可以使用苹果旧版本的 Bitpie 无法享受全部的功能，给用户造成了极大的不便。

 
为了尽快解决苹果商店版本无法更新的问题，我们将比特派 iOS 版的运营主体改为比特派加拿大公司 BITPIE TECHNOLOGY INC 。来满足苹果公司对比特派的问询。现在您可以放心地使用 App Store 里新版本 Bitpie ，不用担心其他政策限制问题。中国大陆区的用户需要将 App Store 切换为海外账户来下载 Bitpie ，海外 App Store  账号申请使用指南：<a href="https://www.jianshu.com/p/b437b15a35cd" target="_blank" style="color:red">点击</a>


备注：<br/>
Bitpie 以后的更新都会在海外版 App Store 提交，将不再提供企业证书版（非苹果商店下载且需要在设置里对证书需要信任的版本为企业证书版，APP 图标左上角有内测字样）的更新。<span style="color:red">之前使用企业证书版的用户不要卸载原 APP ，请将记好的密语导入到新的 App Store 版本恢复使用，App Store 版本与内测版为两个独立的 APP 不会互相覆盖。</span><br/>
丢失密语的企业证书版用户，不要卸载原 APP ，请发送邮件到<a href="mailto:guozixxg@bitpie.com" target="_blank"> guozixxg@bitpie.com </a>邮件需要说明以下几点：<br/>
1.本人真实姓名。<br/>
2.联系方式（微信、电话）。<br/>
3.描述清晰自己的情况。比特派将不再提供企业证书版的更新，请您及时下载 App Store 版本，并恢复您的资产。<br/>
比特派没有任何的 QQ 群、QQ 客服，所有的 QQ 客服都是骗子，请不要向任何人（包括比特派员工）泄露您的密语及相关信息。
 
 

比特派团队<br/>
2018年4月17日