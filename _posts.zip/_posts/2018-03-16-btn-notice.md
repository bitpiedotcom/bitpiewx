---
layout: post
title: 关于暂停 BTN 发送及充提服务的通知
author: 
lang: zh
data: 2018-03-16
post_id: 13
id: 13
ref: ad
time: 
---

由于 BTN 团队将于2018年3月18-19日进行 BTN 主网升级，升级期间，BTN 链上转账交易可能会被视为无效。因此，比特派将在 BTN 主网升级期间采取如下措施：
```
1.BTN 钱包将于2018年3月17日0时起暂停 BTN 发送服务，BTN 升级期间，强烈建议用户请勿收发 BTN，否则可能造成资产损失。
2.派银行将于2018年3月17日0时起停止 BTN 充提服务，恢复时间视 BTN 主网升级完成时间而定。
3.ExPie 中的 BTN 交易对不受此次升级影响，可正常交易。

```


BTN官方升级公告详见：<a href="http://www.btn.org/download/Announcement.pdf" target="_balnk" style="color:red;text-decoration:underline">http://www.btn.org/download/Announcement.pdf</a>




比特派团队<br/>
2018年03月16日


