---
layout: post
title: Server Upgrade Notification
author: 
lang: en
data: 2018-05-15
post_id: 27
id: 27 
ref: ad
time: 

---


Dear Bitpie users:

Due to the recent surge in the number of users, the visits to some regions have been slow. In order to bring you a more convenient and comfortable experience, we need to upgrade the server hardware. You will not be able to send, receive, and trade during updating.

Please wait patiently，thank you for your understanding and support.

Bitpie team<br/>
May 15, 2018
