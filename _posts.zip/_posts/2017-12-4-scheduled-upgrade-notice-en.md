---
layout: post
title: Scheduled Server Upgrade Notification
author: 
lang: en
data: 2017-12-4
post_id: 2
id: 2
ref: ad
time: 
---


In order to provide better service quality and trading experience, Bitpie will conduct server upgrade on 14:30, Dec. 4th, 2017 (UTC +0).  During the upgrade, wallet function will not be accessible, trading will be suspended. The estimated upgrade time can be as long as 2 hours, the service resume time will be 16:30, Dec. 4th, 2017 (UTC +0). 

We apologize for any inconvenience this upgrade may cause and appreciate your patience.

Bitpie Team

