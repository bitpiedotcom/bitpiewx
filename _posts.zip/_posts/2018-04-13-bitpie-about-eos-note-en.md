---
layout: post
title: Bitpie Plan on EOS Ecosystem
author: 
lang: en
data: 2018-04-13
post_id: 21
id: 21
ref: ad
time: 
---


As the EOS mainnet launching is approaching, many candidates have published campaign plans for eos-block producers or airdrop programs. Bitpie is a firm supporter of EOS ecosystem and keeping updated for the development of the project as well as close contact with Block.one team. For the campaigns of the eos-block producers, we also maintain a keen interest in it and will gradually publish our plans as the case may be. Furthermore, we open our doors to all the eos-producer candidates in of hope of engaging in the community and ecosystem building.

Boasting a number of technical strengths, Bitpie team has carried out plenty of technical works regarding EOS-related R&D; and we will launch the EOS mainnet wallet and provide EOS claiming service. As usual, Bitpie users will enjoy quick and safe operations of your EOS wallets. We will also support all the airdrops related to EOS holders. As a partner with Block.one ecosystem, Bitpie will support applications based on EOS architecture and open access of EOS Dapps to partners. We will participate in EOS Dapp's incubation and launch a series of specific scenarios to EOS holders to bring more scenarios and a better experience for users.

For EOS holders, Bitpie is your safest and most convenient choice regarding EOS mapping and managing your EOS assets. For EOS developing teams, if you are developing relevant programs on EOS platform, please do not hesitate to contact us: <a href="mailto:B@bitpie.com" target="_blank"> B@bitpie.com </a>. 

Your support will be highly appreciated. 

Bitpie Team
April 13, 2018