---
layout: posts
title: "比特派 + ETH"
author: "文浩"
lang: "zh"
ref: eth
---

![eth图片](/image/eth.jpg "比特派支持ETH")


比特派团队

2017年9月6日

