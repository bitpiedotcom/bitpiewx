---
layout: post
title:  关于 SHOW 推出 ShowCoin 智能合约2.0
author: 
lang: zh
data: 2018-06-28
post_id: 41
id: 41
ref: ad
time: 
---

尊敬的用户：

SHOW 团队将在2018年6月28日18:00:00-2018年6月29日16:00:00（GMT+8）对秀币代码进行升级，合约代码 name 升级为 ShowCoin2.0。

针对此次合约升级，SHOW 团队将在2018年6月29日00:00:00（GTM+8）对现有持币地址进行快照，新的合约正式启用后会按照完全映射（1:1空投）给用户。原合约将会被弃用，对应的代币也将不再作为价值凭证。

在比特派钱包持有 SHOW 币的用户需要注意:<br/>
<span style="color:red">1、在此期间 Bitpie 钱包内原 SHOW 币的收发功能可正常使用，快照时间为2018年6月29日00:00:00（GTM+8）对现有区块进行，请用户注意快照时间，避免在临近快照时刻收发币，造成不必要的新SHOW币资产损失。官方团队后续会按照快照进行新币空投，请用户耐心等待。</span><br/>
<span style="color:red">2、原有代币将被更名为 “OLD SHOW”，新的代币名称仍然为 “SHOW”，原有代币将永久不再作为价值凭证。</span>


详情请见SHOW官方公告：<a href="http://info.show.one/index.php/archives/502/" target="_blank">点击</a>

比特派团队<br/>
2018年06月28日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>