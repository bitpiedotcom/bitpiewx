---
layout: post
title: BITHD 发货及第二批销售公告
author: 
lang: zh
data: 2018-03-30
post_id: 17
id: 17
ref: ad
time: 
---


让您久等了！BITHD 开始发货啦！我们将按照尾款付款顺序依次发货。由于工厂正月十五以后才开始陆续安排生产，导致发货时间延后，望理解！BITHD 第二批正在生产中，即将全面开放销售。

BITHD 比特护盾您值得拥有，一个真正做到能让大妈也能轻松使用的硬件钱包，BITHD 也是第一个可穿戴的、给区块链世界的未来带来无限可能玩法的硬件设备。


付尾款教程：<a href="http://docs.bitpie.com/zh_CN/latest/piestore/index.html" target="_blank" style="color:red">点击</a><br/>
BITHD 视频教程：<a href="http://v.youku.com/v_show/id_XMzQ2ODEwMTUwNA==.html" target="_blank" style="color:red">点击</a><br/> 
Bitpie 比特派 iOS 版终结解决方案 BITHD 视频：<a href="http://www.miaopai.com/show/g~wivMcjvOjyAZx0XMthZfBcR9ORwimSNqPXXQ__.htm" target="_blank" style="color:red" >点击</a><br/> 
BITHD 使用文档：<a href="http://docs.bithd.com" target="_blank" style="color:red">点击</a>


祝您使用 BITHD 愉快！如有疑问请关注微博<a href="https://weibo.com/bitpiewallet" target="_blank">@比特派钱包</a>或“比特派社区”微信公众号与比特派工作人员联系。



比特派团队<br/>
2018年03月30日