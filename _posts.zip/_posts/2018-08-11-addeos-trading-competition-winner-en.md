---
layout: post
title:  ADD/EOS Trading Competition Winner Lists (Day Two 9th -10th Aug.)
author: 
lang: en
data: 2018-08-11
post_id: 52
id: 52
ref: ad
time: 
---

At 16:00 8th August, Bitpie listed the ADD/EOS trading pair in its built-in exchange. To extend the gratitude to our users’ trust and supports, Bitpie and ADD launched the trading competition of ADD/EOS with multiple rewards. For details, please <a href=" https://bitpie.com/2018-08-06/addeos-trading-competition-note-en
" target="_blank" style="color:red">click</a>

<strong style="color:red">I Daily Giveaway</strong>

1.Awards for largest daily trading volume. Users who participate in ADD/EOS trading in Bitpie’s built-in exchange will be ranked every 24 hours pursuant to the purchase volume (buying volume minus selling volume). The trading period is 16:00 9th -16:00 10th Aug.
The winning UIDs are:<br/>
151550＊,155367＊,27205＊,27205*,155382＊<br/>
28580＊,10195＊,23726＊,22754＊,155334＊<br/>
28580＊,155382＊,35644＊,23726＊,36613＊<br/>
155367＊,36454＊,155367＊,14171＊,154763＊<br/>
33080＊,23864＊,19868＊,26642＊,32719＊,23889＊<br/>
21281＊,12261＊,18385＊,10198＊,14474＊,27527＊<br/>
32669＊,21106＊,11364＊,10198＊,31719＊,33591＊<br/>
24634＊,17925＊,30610＊,35422＊,32103＊,23549＊<br/>
30433＊,23522＊,11247＊,16586＊,31298＊,29500＊<br/>



The rewards are:<br/>
Top 1: 50,000 ADD<br/>
Top 2: 20,000 ADD<br/>
Top 3: 10,000 ADD<br/>
Top 4-10: 3,000 ADD per user<br/>
Top 11-50: 500 ADD per user<br/>


2.For the FIRST 100 traders whose trading volume (24h) exceed 100 EOS, 100 ADD giveaways for every 100-EOS-equivalent volume will be awarded pursuant to their TOTAL trading volume (buying plus selling).
The winning UIDs are:<br>
133259＊,26410＊,277412＊ 



Congratulations to the winners! The competition is still ongoing. Welcome to join us!<br/>


Tips:<br/>
• Bitpie reserves the right to cancel or amend the Competition or Competition Rules at our sole discretion.<br/>
• Any intentional wash trading during the Competition period will not be tolerated and may result in disqualification.<br/>
• Rewards will be issued within 15 working days after the competition.<br/>
• The rankings will be updated on Bitpie.com before 20:00 (Hong Kong time) on each working day, and the final list will be published within FIVE working days after the end of the campaign. If no winners are reported within three working days after the final list is published, the list will be deemed as valid and final.<br/>
• Digital assets are innovative investment products, and their prices fluctuate greatly. Please judge your investment ability rationally and make investment decisions prudently.<br/>
• All the time above is Hong Kong Time (UTC+8).<br/>


How to Create a New EOS Account: <a href="http://docs.bitpie.com/en/latest/eosaccount/index.html" target="_blank" style="color:red">Click</a><br/>
How to Import an Existing EOS Account to Bitpie: <a href="http://docs.bitpie.com/en/latest/privateKeyImport/index.html" target="_blank" style="color:red">Click</a>


Enjoy your trading!


Bitpie Team<br/>
August 11, 2018

Find us on<br/>
Telegram:<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter:<a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>
