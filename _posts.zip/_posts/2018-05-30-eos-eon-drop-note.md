---
layout: post
title:  Bitpie 支持 EON 的空投公告
author: 
lang: zh
data: 2018-05-30
post_id: 36
id: 36
ref: ad
time: 
---



尊敬的派钱包用户：


Bitpie 将会支持 EON 的空投。按照 EON 官方规则，EON 将会对持有100个以上 EOS 的用户进行1:1空投，快照时间为香港时间2018年6月1日12:00:00点，请确保快照时你的<span style="color:red"> EOS 数量大于 100</span>并且 <span style="color:red">EON 官方要求在香港时间2018年6月1日12:00:00之前做好 Claim 操作</span>。


对于 EOS 存放在派银行的用户，我们将在空投结束后将统一安排发放，您无需操作。
 

EOS 存放在派钱包中的用户点击链接：<a href="http://docs.bitpie.com/zh_CN/latest/commonContract/index.html#eon-claim" style="color:red" target="_blank">点击</a>获取手动操作教程。


注：EON官方展示信息有限，对EON项目的风险请自行评估。<span style="color:red">比特派 EON 索取(claim) 调用合约功能将在香港时间2018年6月1日12:00:00之后下线。</span>如果您调用过 EON 索取(claim) 合约，耐心等待 EON 项目方发币即可。<br/>
EON 官网：<a href="http://eon.org/#/" target="_blank" style="color:red">http://eon.org/</a>


Bitpie 团队<br/>
2018年5月30日


Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>