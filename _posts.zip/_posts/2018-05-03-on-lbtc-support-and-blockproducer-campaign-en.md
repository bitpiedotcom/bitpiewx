---
layout: post
title: On LBTC Support and Bookkeeping Node Campaign
author: 
lang: en
data: 2018-05-03
post_id: 26
id: 26
ref: ad
time: 

---

Dear users,

Bitpie v3.2.4 now added LBTC (Lightning Bitcoin); meanwhile, Bitpie Team announces the bid for LBTC block producer.
 
Moreover, Bitpie will support the LBTC related trading pairs on ExPie exchange platform and pieotc.com.
 
About LBTC:<br/>
With DPoS consensus mechanism, voting and bookkeeping rights can be separated, which prevents abuse or control of the system by any party. Users can maintain the policy discourse as long as they possess coins, thus achieve the true autonomy.<br/>
LBTC’s fork height: December 18, 2017; block generation time: 3 seconds; block rewards: 0.0625LBTC. Official Website: <a href="http://lightningbitcoin.io/" target="_blank">http://lightningbitcoin.io/</a>.