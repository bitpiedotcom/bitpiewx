---
layout: post
title: 比特派送礼季 - BTG 获奖名单公布
author: 
lang: zh
data: 2017-12-4
post_id: 3
id: 3
ref: ad
time: 
---

比特派送礼季 – BTG 活动已于香港时间2017年12月3日下午6点圆满结束。该活动受到了社区用户的广大欢迎和踊跃参与，感谢大家对本次活动的支持，未来比特派会带来更多类似的活动回馈大家。

以下是本次活动的中奖名单：

<p style="text-align:center;color:#3ECFAF"><strong>一重礼  BTG点对点交易获奖名单</strong></p>

<p style="text-align:center">交易抽奖活动获奖名单 （1 BTG）</p>

<table class="table" border="0" cellspacing="0" cellpadding="0" style="text-align:center">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>109698 </td><td> changzhou</td> <td>182****5777 </td></tr> 
<tr><td>142886 </td><td>  peigang20002 </td> <td>186****8285 </td></tr>
<tr><td>100016</td>  <td>  旺旺好男银    </td>  <td>137****2737  </td> </tr>
<tr><td>150985</td><td>    weishen555  </td><td>134****7567  </td></tr>
<tr><td>118347</td><td>     SZL</td>    <td>189****9152      </td></tr>
                               

</table>

<p style="color:#F46100">恭喜以上幸运用户，每位获得1BTG，奖品会在24小时进入您的派银行余额。</p>

<p style="text-align:center;color:#3ECFAF"><strong>二重礼  充值及交易送币</strong></p>

香港时间2017年11月27日 6：00 PM至 2017年 12月 3日6:00 PM期间内在比特派app“派银行”中进行BTG充值以及BTG交易的前1000名用户均可以获得0,01(充值赠送)以及0.03(交易赠送)。


<p style="text-align:center">BTG交易 部分获奖用户 （0.03 BTG）</p>


<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>101648 </td><td> XiaoBao</td> <td>137****9914</td></tr> 
<tr><td>102275</td><td>sunshuguang</td><td>152****9361</td></tr>
<tr><td>104231</td><td>liulei</td><td>137****7770</td></tr>
<tr><td>108892</td><td>laohua</td><td>136****1805</td></tr>
<tr><td>114529</td><td>KingBTC</td><td>189****5831</td></tr>
<tr><td>125781</td><td>longxuan</td><td>176****3236</td></tr>
<tr><td>136147</td><td>Jashon</td><td>158****5059</td></tr>
<tr><td>137858</td><td>zhaipeng</td><td>137****0227</td></tr>
<tr><td>144513</td><td>muranfei</td><td>139****9110</td></tr>
<tr><td>153804</td><td>shadowbao</td><td>150****5356</td></tr>
<tr><td>119388</td><td>YanCe</td><td>159****2601</td></tr>
<tr><td colspan="3">…及其他符合条件用户</td></tr>

</table>
                              


<p style="text-align:center">BTG充值 部分获奖用户 （0.01 BTG）</p>
<table class="table" border="0" cellspacing="0" cellpadding="0">

<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>102653</td><td>liqingchuan</td><td>137****6880</td></tr>
<tr><td>103781</td><td>btcwin</td><td>136****6280</td></tr>
<tr><td>103801</td><td>zhouqi</td><td>186****2662</td></tr> 
<tr><td>125781</td><td>longxuan</td><td>176****3236 </td></tr>
<tr><td>136147</td><td>Jashon</td><td>158****5059</td></tr>
<tr><td>137858</td><td>zhaipeng</td><td>137****0227</td></tr>
<tr><td>141252</td><td>jianweizhu</td><td>139****4353</td></tr>  
<tr><td>166794</td><td>Alexcsl</td><td>138****9831 </td></tr>
<tr><td>168272</td><td>hongxian</td><td>136****6627  </td></tr> 
<tr><td>176671</td><td>ling520</td><td>182****8520</td></tr>
<tr><td colspan="3">…及其他符合条件用户</td></tr>
</table>



由于BTG交易以及BTG充值活动获奖人数众多，特截取部分获奖用户名单给予公示未列及所有，前1000参与活动的中奖用户获得的BTG都将在24小时内发放至派银行余额。


<br/>
<p style="text-align:center;color:#3ECFAF"><strong>三重礼  微博转发获奖名单（微博昵称）</strong></p>

<p style="text-align:center;font-weight:500">一等奖   坚果Pro 2</p>

<p style="text-align:center">王二为什么昵称总是重复的</p>


<p style="text-align:center;font-weight:500">二等奖  0.2  BTG</p>

逛街小神女喵喵；我只是一锅小小鸟；成颜锋；看穿你的谎言201705；我就胖了就爱吃肉怎么着了；小天田卜腊妮；机器猫羞手羞脚；我爱家乡五月花；MS踩踩_Angelina；小星星来喽_shopping

<p style="text-align:center;font-weight:500">三等奖  0.1 BTG</p>

MR朱睿；随水a；善良聪明的大脑袋小朋友；我嘞个去-微风吹来请自重；陌上熙村君；隔壁少东家o_o；zq_zq__；家有小龙女糊小婷；熙熙卡哇伊_coco；貌比如花美的小妮子

恭喜以上获奖用户，近期工作人员会与您进行联系，请注意微博站内私信。


<p style="color:#F46100">没中大奖也不要气馁，比特派送礼季才刚刚开场，请持续关注我们的微博，微信及APP内公告，很快会有更加重量级的活动在等您，大奖送不停，燃爆整个冬日。</p>

以上活动最终解释权归BITPIE LIMITED所有，如有疑问请关注微博@比特派社区或“比特派社区”微信公众号与比特派工作人员联系。


