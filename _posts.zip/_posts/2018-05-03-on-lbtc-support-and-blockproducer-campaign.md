---
layout: post
title: 关于LBTC（闪电比特币）上架和节点竞选的公告（2018年5月3日）
author: 
lang: zh
data: 2018-05-03
post_id: 26
id: 26
ref: ad
time: 

---


亲爱的用户：

比特派钱包最新版（v3.2.4版）现已支持LBTC（闪电比特币）；同时，比特派宣布：将参与LBTC（闪电比特币）记账节点竞选。


今后，比特派生态内交易所ExPie和PIEOTC.com也将支持LBTC交易对。


项目简介：LBTC（闪电比特币）将DPOS共识机制引入了比特币网络，做到记账权和投票权的分离，从而保证系统不会被滥用，无法单方面劫持其他参与方。只要用户持有币就持有话语权，从而实现真正的共治。LBTC的分叉时间为2017年12月18日（分叉高度499999），出块时间为3秒，每个块奖励0.0625个LBTC。Lightning Bitcoin官方网址：<a href="http://lightningbitcoin.io/" target="_blank">http://lightningbitcoin.io/</a>。

