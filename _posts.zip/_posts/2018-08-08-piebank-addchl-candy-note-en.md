---
layout: post
title:  Announcement of ADD and CHL Airdrops and Open of ADD and CHL Trade in Pie Bank
author: 
lang: en
data: 2018-08-08
post_id: 50
id: 50
ref: ad
time: 
---

Dear Bitpiers,

Pie Bank has opened the receiving of ADD and CHL airdrops. It has also launched ADD/EOS and CHL/EOS trading pairs and ADD trading competition. For more information please <a href="https://bitpie.com/2018-08-06/addeos-trading-competition-note-en" target="_blank" style="color:red">Click</a>.

Bitpie Team<br/>
August 08, 2018

Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>