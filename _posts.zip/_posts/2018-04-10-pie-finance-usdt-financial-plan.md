---
layout: post
title: “派理财”之 USDT 理财活动
author: 
lang: zh
data: 2018-04-10
post_id: 19
id: 19
ref: ad
time: 
---

开售时间：香港时间 2018年04月10日 

应广大USDT 爱好者的要求，继抢手的BCH，ETH理财之后，比特派推出第三款理财产品——<strong>USDT（ERC20版）定期&活期理财！</strong><br/>

<strong>买入即刻计息，若未到期提现将损失利息</strong><br/>
<strong>日产品</strong>：额度有限售完为止，年化利率 1%（按天计算，提现自由）<br/>
<strong>月产品</strong>：额度有限售完为止，年化利率 5%（按整月计算，回报率高）

<strong>购买理财</strong><br/>
下载比特派 APP v3.1.7，在派银行中参与 USDT 理财计划，流程如下：<a href="http://docs.bitpie.com/zh_CN/latest/financialPlan/index.html" target="_blank">理财流程</a><br/>
100 USDT 起投，单账户上限为 100,000 USDT。

<strong>理财产品提现</strong><br/>
存币期间如需交易可在发起提币申请后两个工作日内提取到账，若存币未满一个月提币将无法获得任何收益，等同于放弃活动资格，比特派提醒您谨慎操作！<br/>
<p class="content-bch-info" style="margin-bottom:10px">（注：在法律允许的范围内，比特派保留对本活动的最终解释权）</p>

<div class="box_1">
<div class="div_h5"><span>产品特点</span></div>
<div class="t1">
<div class="div_safe">
安全
</div>
<div class="safe_info">
<p class="safe_info_p"><strong>比特派钱包安全有保障</strong></p>
<p>比特派由比太团队开发，比太团队的“比太钱包”是首个被 <a href="https://bitcoin.org/en/wallets/desktop/windows/bither/" target="_blank">Bitcoin.org</a> 推荐的“国产”比特币钱包。</p>

</div>
</div>


<div class="t1">
<div class="div_safe">
收益
</div>
<div class="safe_info">
<p class="safe_info_p"> <strong>高净值，低风险，收益看的见</strong></p>
<p>为用户提供低风险、收益率适中的理财服务，帮助用户实现稳健的、可预期的资产增值。
</p>

</div>
</div>


<div class="t1 end">
<div class="div_safe">
灵活
</div>
<div class="safe_info">
<p class="safe_info_p"> <strong>整存整取，使用更灵活</strong></p>
<p>根据您的实际需求自由选择活期、定期理财，快捷理财的同时获得相应利息，提币申请后两个工作日内到账，不因理财影响交易。
</p>

</div>
</div>

</div>

<p class="content-bch-p">如果您还不是比特派用户，请在手机浏览器打开下方链接下载安装使用。</p>

<p class="content-bch-p bch-download">安卓: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a><br/>



