---
layout: post
title: Bitpie Wallet Supports BYTOM Blockchain Upgrade and Token Migration
author: 
lang: en
data: 2018-05-17
post_id: 30
id: 30
ref: ad
time: 
---


Fellow Bitpiers,


Bitpie and BYTOM have announced deep ecological cooperation in all aspects.
Today Bitpie Wallet announced that it would support the BYTOM blockchain upgrade and token migration. From now on, investors only need to deposit BTM’s ERC-20 tokens to Pie Bank and will receive the equivalent BTM token on 15th June 2018(UTC+8). For BTM holders who deposit BTM in Pie Bank after June 15th, there will be a weekly exchange.

BTM/SCNY, BTM/ETH trading pairs are now available on the built-in exchange platform ExPie for trading. You can start depositing and trading BTM now.

Risk warning: cryptocurrency investment is subject to high market risk. Please make your investments cautiously. Bitpie will make best efforts to choose high quality coins, but will not be responsible for your investment losses.

Learn more: <a href="https://bytom.io" target="_blank">bytom.io</a>

Thanks for your support!

Bitpie Team<br/>
May 17, 2018


Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>