---
layout: post
title: 比特派送礼季 – BTC/BTG 币币兑换活动获奖名单公布
author: 
lang: zh
data: 2017-12-19
post_id: 7
id: 7
ref: ad
time: 
---

比特派送礼季 – BTC/BTG 币币兑换活动已于香港时间2017年12月16日10：00点圆满结束。活动受到了社区用户的广大欢迎和踊跃参与，感谢大家对本次活动的支持，未来比特派会带来更多类似的活动回馈大家。

以下是本次活动的中奖名单：

<p style="text-align:center;color:#3ECFAF"><strong>币币兑换 大奖 -- 最高交易量 （3 BTG) </strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0" style="text-align:center">
<tr><th>User ID</th><th>用户名</th><th>手机号</th><th>交易量</th></tr>
<tr><td>202001 </td><td>noname-376398456680</td> <td>091****8626</td><td>580.00</td></tr> 
</table>

<p style="color:#F46100">恭喜这位幸运用户，获得3BTG，奖品会在24小时进入您的派银行余额。</p>

<p style="text-align:center;color:#3ECFAF"><strong>总交易量 10 - 50 BTG 获奖名单 （1 BTG）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>138649</td><td>noname-280608344439</td> <td>189****7277</td></tr> 
<tr><td>159452</td><td>noname-921489879966</td><td>***********</td></tr>
<tr><td>121276</td><td>zzproxyss</td><td>138****6464</td></tr>
<tr><td>144452</td><td>laohua</td><td>189****0555</td></tr>
<tr><td>114682</td><td>xuhaif</td><td>139****5761</td></tr>
</table>

<p style="color:#F46100">恭喜以上幸运用户，每位获得1BTG，奖品会在24小时进入您的派银行余额。</p>
                              


<p style="text-align:center;color:#3ECFAF"><strong>总交易量 1 - 10 BTG 获奖名单 （0.25 BTG）</strong></p>
<table class="table" border="0" cellspacing="0" cellpadding="0">

<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>174901</td><td>noname-267600409186</td><td>159****5666</td></tr>
<tr><td>132022</td><td>lamdeng14</td><td>138****4663</td></tr>
<tr><td>201521</td><td>wuxin555</td><td>177****8283</td></tr> 
<tr><td>157521</td><td>twoapples</td><td>136****5752</td></tr>
<tr><td>167449</td><td>woxinfeiyang</td><td>156****2322</td></tr>
<tr><td>103781</td><td>btcwin</td><td>136****6280</td></tr>
<tr><td>150531</td><td>wy-20171010</td><td>153****8027</td></tr>
<tr><td>105425</td><td>noname-251861544547</td><td>186****6480</td></tr>
<tr><td>196555</td><td>yusufy</td><td>138****9077</td></tr>
<tr><td>144889</td><td>zhongxun</td><td>137****2999</td></tr>
<tr><td>151032</td><td>guoyong1978</td><td>135****3768</td></tr>
<tr><td>195176</td><td>CaaKen</td><td>152****3922</td></tr>
<tr><td>148718</td><td>noname-799338700004</td><td>153****2951</td></tr> 
<tr><td>118256</td><td>hangqiao168</td><td>159****9737</td></tr>
<tr><td>182439</td><td>noname-069481413570</td><td>138****1930</td></tr>
<tr><td>121083</td><td>suwanrong</td><td>185****8166</td></tr>
<tr><td>149833</td><td>noname-643896173891</td><td>130****5698</td></tr>
<tr><td>127517</td><td>sl</td><td>180****9966</td></tr>
<tr><td>143173</td><td>cucjason</td><td>186****8115</td></tr>
<tr><td>186639</td><td>Nicole-525</td><td>150****2098</td></tr>
</table>



<p style="color:#F46100">恭喜以上幸运用户，每位获得0.25BTG，奖品会在24小时进入您的派银行余额。</p>



<p style="color:#F46100">没中大奖也不要气馁，比特派送礼季才刚刚开场，请持续关注我们的微博，微信及APP内公告，很快会有更加重量级的活动在等您，大奖送不停，燃爆整个冬日。</p>

以上活动最终解释权归BITPIE LIMITED所有，如有疑问请关注微博<a href="https://weibo.com/bitpiewallet" target="_blank">@比特派社区</a>或“比特派社区”微信公众号与比特派工作人员联系。


