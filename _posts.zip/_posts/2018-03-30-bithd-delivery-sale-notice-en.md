---
layout: post
title: Announcement on BitHD Delivery and 2nd Round of Sales
author: 
lang: en
data: 2018-03-30
post_id: 17
id: 17
ref: ad
time: 
---


Dear customers

BitHD delivery now starts! We are sending out the commodities as per the sequence of the balance payments. The shipment was delayed due to the suspension of OEMs producing during the Chinese Spring Festival (15th Feb-2nd Mar.). We appreciate your patience and understanding. The 2nd batch is under producing now, and soon will be up for sale publicly. 


We are committed to create such a Hardware Wallet that even newbies can easily pick up. BitHD is the first wearable device that brings infinite possibilities to blockchain world!


Pay balance: <a href="http://docs.bitpie.com/zh_CN/latest/piestore/index.html" target="_blank" style="color:red">Click</a><br/>
BitHD Video: <a href="http://v.youku.com/v_show/id_XMzQ2ODEwMTUwNA==.html" target="_blank" style="color:red">Click</a><br/>
BitHD Manual: <a href="http://docs.bithd.com" target="_blank" style="color:red">Click</a>


Hope you enjoy the unforgettable and ultimate using experience of BitHD! 
Join in us on telegram: <a href="https://t.me/BitpieInternational" target="_blank" style="color:red">t.me/BitpieInternational</a>; twitter: <a href="https://twitter.com/BitpieWallet" target="_blank" style="color:red">@BitpieWallet</a>. Please feel free to contract us.


