---
layout: post
title:  Resumption of Sending Zcash(ZEC)
author: 
lang: en
data: 2018-08-10
post_id: 51
id: 51
ref: ad
time: 
---

Dear Bitpiers,

The upgrade of Zcash mainnet, Overwinter, is completed and Bitpie Wallet has finished the testing and upgrade targeting Zcash mainnet. Now the sending service of Zcash is resumed. Please update your Bitpie Wallet to the latest version v3.4.6 and enjoy the sending service.

Thanks for your support for Bitpie Wallet.

Bitpie Team<br/>
August 10, 2018