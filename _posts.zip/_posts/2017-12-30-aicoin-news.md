---
layout: post
title: 比特派新比特派/比太团队发布冷钱包终极解决方案 - 比特护盾（BITHD）
author: 
lang: zh
data: 2017-12-30
post_id: 1
id: 1
ref: news
time: 
urls: http://www.aicoin.net.cn/amp/services/news-share?id=3762&lang=zh&from=timeline
---

AICoin 2017-12-30 15:06:18 了解比太历史的人都知道，我们最初是一个由四名码农组成的技术团队，我们很拼，也艰苦奋斗了好几年，很不容易。码农团队的特点大家懂的，虽然比特币/区块链行业很“浮躁”，我们这个技术团队仍然保持了相当程度的“出淤泥而不染”
