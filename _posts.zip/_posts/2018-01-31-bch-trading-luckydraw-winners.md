---
layout: post
title: 比特派送礼季 - 2018 第一弹 BCH 一键买卖活动获奖名单公布
author: 
lang: zh
data: 2018-01-31
post_id: 9
id: 9
ref: ad
time: 
---

比特派送礼季 – 2018 第一弹 BCH 一键买卖活动已圆满结束。活动受到了社区用户的广大欢迎和踊跃参与，感谢大家对本次活动的支持，未来比特派会带来更多类似的活动回馈大家。


以下是参与2018 第一弹 BCH 一键买卖活动获奖名单表：

<p style="text-align:center;color:#3ECFAF"><strong> 一等奖 1人 1 BCH + iPhoneX  </strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0" style="text-align:center">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>104614</td><td>108sui</td><td>*******9510</td></tr>
</table>

<p style="color:#F46100">恭喜这位用户，1 BCH 已经进入您的派银行余额，iPhoneX 随后将邮寄。</p>


<p style="text-align:center;color:#3ECFAF"><strong>二等奖 2人 0.5 BCH + iPhoneX</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>121320</td><td>MadFrog</td><td>*******1955</td></tr>
<tr><td>140709</td><td>wxalloy</td><td>*******7712</td></tr>


</table>

<p style="color:#F46100">恭喜这两位用户，0.5 BCH 已经进入您的派银行余额，iPhoneX 随后将邮寄。</p>

<p style="text-align:center;color:#3ECFAF"><strong>三等奖 5名 0.5 BCH </strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>100046</td><td>Flypig</td><td>*******0089</td></tr>
<tr><td>117517</td><td>Rrrrrrr</td><td>*******3986</td></tr>
<tr><td>179618</td><td>mm1984</td><td>*******6263</td></tr>
<tr><td>152453</td><td>noname-996564679259</td><td>********3800</td></tr>
<tr><td>207300</td><td>*******8668</td><td>*******8668</td></tr>
</table>

<p style="color:#F46100">恭喜以上用户，0.5 BCH 已经进入您的派银行余额。</p>


<p style="text-align:center;color:#3ECFAF"><strong>四等奖 10名 0.1 BCH </strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>101993</td><td>Cedar</td><td>*******5968</td></tr>
<tr><td>122451</td><td>noname-571901757642</td><td>*******8912</td></tr>
<tr><td>138449</td><td>aryama</td><td>*******5909</td></tr>
<tr><td>143492</td><td>wakerfung</td><td>*******0717</td></tr>
<tr><td>158209</td><td>360125880</td><td>*******2538</td></tr>
<tr><td>191891</td><td>noname-170400764077</td><td>*******3573</td></tr>
<tr><td>196300</td><td>lvkk</td><td>*******0149</td></tr>
<tr><td>206029</td><td>10kalories</td><td>*******6699</td></tr>
<tr><td>223385</td><td>noname-335385844968</td><td>*******3661</td></tr>
<tr><td>208574</td><td>rmlz</td><td>*******6277</td></tr>
</table>

<p style="color:#F46100">恭喜以上用户，0.1 BCH 已经进入您的派银行余额。</p>

<p style="text-align:center;color:#3ECFAF"><strong>五等奖 50名 0.05 BCH </strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>101517</td><td>bitflower</td><td>*******6418</td></tr>
<tr><td>101942</td><td>jiangG</td><td>*******1796</td></tr>
<tr><td>101992</td><td>brmrk</td><td>*******6622</td></tr>
<tr><td>102970</td><td>da</td><td>*******7377</td></tr>
<tr><td>103840</td><td>Netfree</td><td>*******3511</td></tr>
<tr><td>106383</td><td>Anatta</td><td>*******8513</td></tr>
<tr><td>108701</td><td>noname128468930524</td><td>*******2803</td></tr>
<tr><td>116737</td><td>bi-bi</td><td>*******5152</td></tr>
<tr><td>121082</td><td>Bitcoiner001</td><td>********2520</td></tr>
<tr><td>121541</td><td>asmogy</td><td>********0671</td></tr>
<tr><td>123949</td><td>crystalzj0</td><td>*******3138</td></tr>
<tr><td>124410</td><td>lijy-80934542</td><td>*******6399</td></tr>
<tr><td>128152</td><td>tedteng</td><td>*******5421</td></tr>
<tr><td>132337</td><td>yrj</td><td>*******8779</td></tr>
<tr><td>133892</td><td>Ontheway2017</td><td>*********8915</td></tr>
<tr><td>137309</td><td>busong</td><td>********9325</td></tr>
<tr><td>140801</td><td>nick-liu</td><td>*******3008</td></tr>
<tr><td>142729</td><td>zhangying7</td><td>*******8852</td></tr>
<tr><td>142901</td><td>Fancy</td><td>*******9177</td></tr>
<tr><td>140579</td><td>BCC</td><td>*******4700</td></tr>
<tr><td>146189</td><td>bt5599</td><td>*******5895</td></tr>
<tr><td>143359</td><td>laoniu88</td><td>*******6808</td></tr>
<tr><td>145062</td><td>liuhui2016</td><td>*******7302</td></tr>
<tr><td>148001</td><td>Zxt</td><td>*******0805</td></tr>
<tr><td>148065</td><td>Yoyo-19850327</td><td>*******8809</td></tr>
<tr><td>148449</td><td>noname-048454142462</td><td>*******6007</td></tr>
<tr><td>154328</td><td>sally888</td><td>*******4401</td></tr>
<tr><td>155073</td><td>ysfyjx</td><td>*******1688</td></tr>
<tr><td>155976</td><td>charles18</td><td>*******11033</td></tr>
<tr><td>157420</td><td>billkingliu</td><td>*******2528</td></tr>
<tr><td>163938</td><td>GSong</td><td>*******3147</td></tr>
<tr><td>164927</td><td>snihha</td><td>*******5957</td></tr>
<tr><td>165507</td><td>xiexiaoyang</td><td>*******1599</td></tr>
<tr><td>166746</td><td>18651746818</td><td>*******6818</td></tr>
<tr><td>170590</td><td>jujiu</td><td>********9805</td></tr>
<tr><td>177280</td><td>blockfish</td><td>********1100</td></tr>
<tr><td>179350</td><td>TKR</td><td>*******0397</td></tr>
<tr><td>180747</td><td>noname-366564450517</td><td>*******3177</td></tr>
<tr><td>180798</td><td>Bitcoiner007</td><td>*******9178</td></tr>
<tr><td>188523</td><td>btcguy</td><td>*******1023</td></tr>
<tr><td>193665</td><td>fanlin--1977</td><td>*******3999</td></tr>
<tr><td>194524</td><td>justmade</td><td>*******5491</td></tr>
<tr><td>196713</td><td>noname-972066713541</td><td>*******5259</td></tr>
<tr><td>197790</td><td>544545-hsh</td><td>*******0158</td></tr>
<tr><td>202556</td><td>zcwad</td><td>*******2992</td></tr>
<tr><td>204202</td><td>jiemona</td><td>*******0926</td></tr>
<tr><td>208045</td><td>noname-320746615431</td><td>*******3385</td></tr>
<tr><td>215201</td><td>emily52059</td><td>*******3610</td></tr>
<tr><td>221284</td><td>Hbxfpc</td><td>********3333</td></tr>
<tr><td>225961</td><td>noname-197977346468</td><td>*******8541</td></tr>
</table>

<p style="color:#F46100">恭喜以上用户，0.05 BCH 已经进入您的派银行余额。</p>

<p>如有疑问请关注微博<a href="https://weibo.com/bitpiewallet" target="_blank">@比特派社区</a>或“比特派社区”微信公众号与比特派工作人员联系。</p>
