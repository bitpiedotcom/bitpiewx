---
layout: post
title: 比特派新比特派/比太团队发布冷钱包终极解决方案 - 比特护盾（BITHD）
author: 
lang: zh
data: 2017-12-30
post_id: 1
id: 1
ref: news
time: 
urls: https://mp.weixin.qq.com/s/PHBJaW8kUW-duMeKb7Hg2g
---

白话区块链 12月30日讯 未来已来，BITHD 是第一个真正做到能让大妈也能轻松使用的硬件钱包，BITHD 也是第一个可穿戴的、给区块链世界的未来带来无限可能玩法的硬件设备，BITHD 来了！
