---
layout: posts
title: "Bitpie + Zcash"
author: "Wenhao"
lang: "en"
ref: "zcash"
---
Today, we are very happy to announce Bitpie v2.2.1 will support Zcash (ZEC)!

Zcash is a more privacy focused digital currency, it is based on zk-SNARK zero knowledge proof technology, and can provide better privacy protections to users.
Since the begining, many miners in China participate in Zcash mining, also there are many users in China keep and use Zcash. In the past few months, many people are asking us to support Zcash, so we decide to support it.
Two Months ago, when Zooko (Zcash CEO) and Zirui visited Beijing, Bitpie/Bither's CEO Wen Hao had a great conversation with them, and at that time, we had dicided to support Zcash in September, Zooko had told us that Zcash team will provide support in technical development.

And today, Zcash on Bitpie is here!

Special thanks to Zooko!

Bitpie Team

2017-09-12

