---
layout: post
title:  ADD/EOS 交易竞赛获奖名单（第二期 8月9日 - 10日）
author: 
lang: zh
data: 2018-08-11
post_id: 52
id: 52
ref: ad
time: 
---

2018 年 8 月 8 日 16：00， 比特派 Bitpie 正式开通 ADD/EOS 交易对，为感谢平台用户的支持和信任，连同 ADD 同步上线交易大赛以及三重奖励，花样送好礼，详情可<a href="https://bitpie.com/2018-08-06/addeos-trading-competition-note" target="_blank" style="color:red">点击</a>了解。

<strong style="color:red">一、交易大赛赢壕礼！</strong>

其中交易竞赛活动，通过统计每日用户交易量进行排名，并发放奖励。现将第二期的交易竞赛即交易时间段为：8 月 9 日 16:00 – 10日16:00 的中奖明细公示如下：

1、每日实力排名奖：<br/>
中奖账户为：<br/>
第1名：155367＊ <br/>
第2名：151550＊ <br/> 
第3名：155367＊ <br/>
第4-10名：
27205*,155382＊,28580＊,10195＊,23726＊,22754＊,155334＊<br/>
第11-50名：<br/>
28580＊,155382＊,35644＊,23726＊,36613＊<br/>
155367＊,36454＊,155367＊,14171＊,154763＊<br/>
33080＊,23864＊,19868＊,26642＊,32719＊,23889＊<br/>
21281＊,12261＊,18385＊,10198＊,14474＊,27527＊<br/>
32669＊,21106＊,11364＊,10198＊,31719＊,33591＊<br/>
24634＊,17925＊,30610＊,35422＊,32103＊,23549＊<br/>
30433＊,23522＊,11247＊,16586＊,31298＊,29500＊<br/>

奖励为：<br/>
第1名：50,000 ADD<br/>
第2名：20,000 ADD<br/>
第3名：10,000 ADD<br/>
第4-10名：每位用户 3,000 ADD<br/>
第11-50名： 每位用户500 ADD<br/>
                        


2、每日阳光普照奖：<br/>
中奖账户为：<br/>
133259＊,26410＊,277412＊ 

中奖者均可获得100 ADD 奖励。


<span style="color:red">恭喜中奖用户，交易活动仍在持续进行，欢迎大家前来参与！</span>

注：<br/>
温馨提示：<br/>
• 活动最终解释权归比特派 Bitpie 所有；<br/>
• 活动期间，如有恶意刷量行为，将取消参赛资格；<br/>
• 阳光奖的用户与实力奖的用户可以重叠；<br/>
• 活动结束后15个工作日内发放奖励。<br/>
• 活动排名每个工作日20:00前在 bitpie.com 官网更新展示，最终榜单活动结束后五个工作日内公布，最终榜单公布后三个工作日内无举报则按排名发放奖励。<br/>
• 数字资产是创新的投资产品，价格波动较大，请您理性判断自己的投资能力，审慎做出投资决策。<br/>
• 以上时间均为香港时间（UTC+8）。


创建账户教程：<a href="http://docs.bitpie.com/zh_CN/latest/eosaccount/index.html" target="_blank" style="color:red">点击</a><br/>
如果您在其它钱包有EOS账户，也可以导入比特派。导入教程：<a href="http://docs.bitpie.com/zh_CN/latest/privateKeyImport/index.html" target="_blank" style="color:red">点击</a>
祝您交易愉快！


比特派团队<br/>
2018年08月11日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>

