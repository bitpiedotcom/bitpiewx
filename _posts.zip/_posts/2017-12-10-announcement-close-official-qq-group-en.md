---
layout: post
title: Announcement About Close QQ Chatgroup Support Service in China
author: 
lang: en
data: 2017-12-10
post_id: 4
id: 4
ref: ad
time: 2017-12-10
---

In past weeks, there are a number of users reported there were criminals reached out our user via official QQ Chat group. They said they are technical support from Bitpie , asked for seed and steal user assets.

We made a lot of attempts to resolve this but those threats are still existing.  To protect our users from being scammed, we decide to disband all official QQ chat Group from now.

For technical support you can reach us via in-APP support page( Home - Settings – Feedback ) , our service team will reach out you soon.

Last but not least: 

1.There will be no official chatgroup from now no, all so called Bitpie official QQ chat group are scam.

2.It is very important for you to write down your recovery seed and to store it safely, away from prying eyes. Beware that anyone with access to your seed can steal your assets. Therefore, never make a digital copy of your recovery seed and never upload it to online services. Do not lose your seed. Do not disclose your recovery seed to anyone, even including Bitpie Staff.

Thanks for your support!

Bitpie team.

