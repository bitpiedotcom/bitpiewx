---
layout: post
title:  ADD/EOS Trading Competition Winner Lists (Day Five 12th -13th Aug.)
author: 
lang: en
data: 2018-08-19
post_id: 52
id: 52
ref: ad
time: 
---

At 16:00 8th August, Bitpie listed the ADD/EOS trading pair in its built-in exchange. To extend the gratitude to our users’ trust and supports, Bitpie and ADD launched the trading competition of ADD/EOS with multiple rewards. For details, please <a href=" https://bitpie.com/2018-08-06/addeos-trading-competition-note-en
" target="_blank" style="color:red">click</a>

<strong style="color:red">I Daily Giveaway</strong>

1.Awards for largest daily trading volume. Users who participate in ADD/EOS trading in Bitpie’s built-in exchange will be ranked every 24 hours pursuant to the purchase volume (buying volume minus selling volume). The trading period is 16:00 12th -16:00 13th Aug.
The winning UIDs are:<br/>
19986＊, 14445＊, 155367＊, 155367＊, 28580＊, 19186＊, 27239＊,<br/>
113425＊,97438＊, 34875＊, 17384＊,19459＊,28495＊,38461＊,27472＊,<br/>
16251＊,12255＊,18464＊,24851＊,26782＊,11243＊, 12448＊,26451＊,<br/>
23542＊,21130＊, 19162＊,34781＊,33958＊,29140＊,48498＊,25073＊,<br/>
22495＊,2948＊,2893＊,30225＊,32481＊,22182＊,24124＊,17243＊,<br/>
13457＊,13121＊,44681＊,28472＊,13557＊,19333＊,2345＊,2045＊,<br/>
33975＊,21366＊,13538＊,13690＊,31411＊,11152＊,1137＊,12239＊ <br/>



The rewards are:<br/>
Top 1: 50,000 ADD<br/>
Top 2: 20,000 ADD<br/>
Top 3: 10,000 ADD<br/>
Top 4-10: 3,000 ADD per user<br/>
Top 11-50: 500 ADD per user<br/>


2.For the FIRST 100 traders whose trading volume (24h) exceed 100 EOS, 100 ADD giveaways for every 100-EOS-equivalent volume will be awarded pursuant to their TOTAL trading volume (buying plus selling).
The winning UIDs are:<br>
45600＊,19098＊,10129＊,23850＊


<strong style="color:red">II Rewards for Depositing—Millions of ADD to Give Away!</strong>

The winning UIDs are:<br/>
12167＊,16153＊,19108＊,14375＊,155337＊,155399＊,26016＊,<br/>
22596＊,155297＊,155346＊,153446＊,155313＊,25548＊,36338＊,<br/>
27418＊,25928＊,12448＊,26451＊,23542＊,21130＊, 36454＊,12367＊,<br/>
12791＊,18387＊, 18235＊,19624＊,27873＊,35395＊,24726＊,18463＊,<br/>
16203＊,19134＊,19186＊,10195＊,15088＊, 155367＊,14171＊,154763＊,<br/>
33080＊,23864＊,19868＊,26642＊,32719＊,23889＊,21281＊,12261＊,<br/>
18385＊,10198＊,14474＊,27527＊,32669＊,21106＊,11364＊,1358＊,31719＊<br/>


Congratulations to the winners! The competition is over from this day. Thanks for your support and participation. Bitpie will hold more such trading activities with high rewards for our users in the future. Please stay tuned!
<br/>


Tips:<br/>
• Bitpie reserves the right to cancel or amend the Competition or Competition Rules at our sole discretion.<br/>
• Any intentional wash trading during the Competition period will not be tolerated and may result in disqualification.<br/>
• Rewards will be issued within 15 working days after the competition.<br/>
• The rankings will be updated on Bitpie.com before 20:00 (Hong Kong time) on each working day, and the final list will be published within FIVE working days after the end of the campaign. If no winners are reported within three working days after the final list is published, the list will be deemed as valid and final.<br/>
• Digital assets are innovative investment products, and their prices fluctuate greatly. Please judge your investment ability rationally and make investment decisions prudently.<br/>
• All the time above is Hong Kong Time (UTC+8).<br/>



Bitpie Team<br/>
August 19, 2018

Find us on<br/>
Telegram:<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter:<a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a><br/>
Medium:<a href="https://medium.com/@Bitpie" target="_blank">medium.com/@Bitpie</a>

