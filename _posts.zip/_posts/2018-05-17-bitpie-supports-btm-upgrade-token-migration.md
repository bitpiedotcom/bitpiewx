---
layout: post
title:  派钱包支持比原链 Bytom（BTM）主网更新及代币迁移
author: 
lang: zh
data: 2018-05-17
post_id: 30
id: 30
ref: ad
time: 
---


亲爱的派友：

比特派 Bitpie 与比原链 Bytom 已宣布全面生态合作，双方将在多方面展开深度合作。


今天派钱包宣布支持比原链主网更新及代币迁移，用户可于今日起，将比原链的 ERC20 代币充值进入派钱包的派银行，便可在6月15日（香港时间）通过派银行收到等额的 BTM 主网币资产，无需其他任何操作。针对6月15日之后存入派银行的 BTM 用户，派钱包将会在每周进行集中兑换。

Bitpie 内置交易所（ExPie）现已上线并开通 BTM/SCNY、BTM/ETH 交易市场，邀您体验！
派银行BTM充值通道现已开放。

风险提示：数字货币是一种高风险的投资方式，请投资者谨慎购买，并注意投资风险。Bitpie 会遴选优质币种，但不对投资行为承担担保、赔偿等责任。

比原链 Bytom 官网：<a href="https://bytom.io" target="_blank">bytom.io</a>了解更多信息！

感谢您对比特派 Bitpie 的支持！

比特派团队<br/>
2018年05月17日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>
