---
layout: post
title: Launch of BCH “one click buy/sell” service
author: 
lang: en
data: 2018-01-02
post_id: 8
id: 8
ref: ad
time: 
---

“One click buy/sell” is a very popular service that Bitpie launched in Jan. 2017. Compares to traditional OTC model, “one click buy/sell” will lead user’s request to Bitpie screened 3rd party traders who can provide professional trading service. Users don’t need to worry about fraud and are guaranteed to strike a bargain.

To make a better user experience, our one click service only support BTC trade in 2017. Now we are very happy to announce that BCH “one click buy/sell” has just launched on Bitpie v.2.6.1.

Please be aware that user must to pass the phone verification and finish KYC 5-level verification to use “one click buy/sell” services. If the phone verification has not covered your area, please stay tuned. We are working hard to support all major countries very soon.

If you are not currently a Bitpie user, please use following link to download and install Bitpie App.

Android: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a>

iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>

Help:  <a class="link_app" href="http://docs.bitpie.com/en/latest/" target="_blank">http://docs.bitpie.com/en/latest/</a>



