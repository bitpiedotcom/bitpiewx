---
layout: post
title:  关于派银行发放 ADD、CHL 糖果并开通交易的公告
author: 
lang: zh
data: 2018-08-08
post_id: 50
id: 50
ref: ad
time: 
---


亲爱的派友：

派银行已进行 ADD、CHL 糖果的发放，同时开通 ADD/EOS、CHL/EOS 交易对及开放 ADD 交易大赛，详情：<a href="https://bitpie.com/2018-08-06/addeos-trading-competition-note" target="_blank" style="color:red">点击</a>

比特派团队<br/>
2018年08月08日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>
