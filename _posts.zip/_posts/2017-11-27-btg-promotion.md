---
layout: post
title: 比特派送礼季 - BTG
author: 
lang: zh
data: 2017-11-27
post_id: 1
id: 1
ref: ad
time: 
---

活动时间：2017年11月27号下午6点 – 2017年12月3号下午6点（香港时间）

为答谢广大用户，比特派联合BTG团队发起送礼活动，活动时间内在比特派“派银行”中充值任意数量BTG，送0.01BTG,进行任意数量BTG点对点交易，再送0.03BTG 。充值送礼和交易送礼均限前一千名用户，每位用户可以各参与一次。

活动期间所有参与过交易的用户有机会参与抽奖，共抽出5名幸运用户，每人赠送1BTG。

注：活动仅限绑定过手机号的比特派用户参加。BTG在活动结束后1-3天内发放致派银行余额。

在12月3日中午12点前关注 @比特派社区 并转发“<a href="https://m.weibo.cn/6404560407/4178748795784208" target="_blank">比特派送礼季正式开场！快来转发抽奖！</a>”此条微博，或关注比特派社区微信号，将这张图片转发朋友圈并截图发送给比特派社区公众号可抽取坚果Pro2和BTG。 快来转发！

<p style="padding:5px 0 0 0!important;line-height:1.3">一等奖：坚果Pro2 1名</p>
<p style="padding:0px !important;line-height:1.3">二等奖：0.2 BTG 共10名</p>
<p style="padding:0px !important;line-height:1.3">三等奖：0.1 BTG 共10名</p>

