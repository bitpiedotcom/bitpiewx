---
layout: post
title: 紧急通知
author: 
lang: zh
data: 2018-03-22
post_id: 15
id: 15
ref: ad
time: 
---


因苹果公司对数字货币不够友好，今早我们发现iOS版比特派和比太应用无法打开，请您仔细阅读以下提示，以确保您的资产安全：


<span>1、您的资产是安全的，如果您已经保管好助记词或密钥，可通过助记词或密钥在安卓设备上安装比特派或比太钱包恢复您的资产。</span><br/>
<span>2、如果您不确定是否保管好了助记词，<strong style="color:red">请不要卸载比特派钱包或比太钱包</strong>，比特派已经在积极联系苹果公司，以便尽早恢复您的iOS版钱包使用权限。</span><br/>
<span>3、安卓版用户不受此影响。</span><br/>




比特派团队<br/>
2018年03月22日

<style>
#content h5{
	color:red;
}
</style>