---
layout: post
title: ビットパイ新品発表会—当選者リスト
author: 
lang: jp
data: 2018-01-25
post_id: 8
id: 8
ref: ad
time: 
---

皆様のおかげ様でビットパイ新品発表会は無事終了いたしました。お客様が遠くからわざわざお越しになったことを御礼申し上げます。


当日で数回抽選イベントを行いました。以下は当選者リストでございます：





<p style="text-align:center;color:#3ECFAF"><strong>一回賞（ 6666 BTW ）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0" style="text-align:center">

<tr><th>User ID</th><th>ユーザー名</th><th>携帯番号</th></tr>
<tr><td>231627 </td><td>chenbtc</td> <td>177****4475</td></tr> 
<tr><td>165121 </td><td>HOWYOUDOIN</td> <td>186****5750</td></tr> 
<tr><td>236630 </td><td>xiaohaibtp</td> <td>132****6464</td></tr> 

</table>






<p style="color:#F46100">おめでとうございます！すでにユーザー様のパイ銀行に6666BTWを振り込みました。</p>

<p style="text-align:center;color:#3ECFAF"><strong>二回賞 （ 1 SBTC ）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>ユーザー名</th><th>携帯番号</th></tr>
<tr><td>222859</td><td>zjun18</td> <td>136****8487</td></tr> 
<tr><td>101521</td><td>HuanYu-BtcOtc</td><td>182****0666</td></tr>
<tr><td>122909</td><td>f2pool-Leah</td><td>177****1282</td></tr>
<tr><td>113924</td><td>dadadada</td><td>135****4666</td></tr>
<tr><td>220831</td><td>liufei-huobi</td><td>153****5080</td></tr>
<tr><td>165121</td><td>HOWYOUDOIN</td><td>186****5750</td></tr>
</table>

<p style="color:#F46100">おめでとうございます！すでにユーザー様のパイ銀行に１SBTCを振り込みました。
</p>
                              


<p style="text-align:center;color:#3ECFAF"><strong>三回賞  （ 10 BCD ）</strong></p>
<table class="table" border="0" cellspacing="0" cellpadding="0">

<tr><th>User ID</th><th>ユーザー名</th><th>携帯番号</th></tr>
<tr><td>207107</td><td>ericgood1</td><td>136****0790</td></tr>
<tr><td>154681</td><td>sunxiaojian</td><td>136****7868</td></tr>
<tr><td>103731</td><td>easydao</td><td>185****2468</td></tr> 
<tr><td>111003</td><td>noname-964117431005</td><td>155****5050</td></tr>

</table>



<p style="color:#F46100">おめでとうございます！すでにユーザー様のパイ銀行に10BCDを振り込みました</p>

<p style="text-align:center;color:#3ECFAF"><strong>実体賞品が当たる方：</strong></p>

<p style="text-align:center;"><strong>一等賞：iPhoneX 1台</strong></p>

<p style="text-align:center;"><strong>当選番号：80012</strong></p>

<p style="text-align:center;"><strong>二等賞：坚果Pro 3台 </strong></p>

<p style="text-align:center;"><strong>当選番号：80161、80079、80098</strong></p>

<p style="text-align:center;"><strong>三等賞：小米バッテリー　 10台</strong></p>

<p style="text-align:center;"><strong>当選番号：80051、80060、80015、80026、80128、80033、80120、80155、80016、80011</strong></p>

<p style="color:#F46100">プレゼントに当たらなかったとしてもがっかりしないでください、ビットパイ季節のキャンペーンイベントが始まったばかりなので、我々のweibo、wechatあるいはアプリの公告などをフォローし続けてください、もっとヘビー級のイベントがあなたを待っています。プレゼントが盛りだくさん！この冬で盛り上がりましょう！
</p>

以上イベントの最終解釈権は Bitpie Limited が保有します。お問い合わせはweibo<a href="https://weibo.com/bitpiewallet" target="_blank">@比特派社区</a>またはwechat “比特派社区”微信公衆号の係員にご連絡ください。
