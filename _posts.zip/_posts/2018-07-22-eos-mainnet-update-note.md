---
layout: post
title:  比特派钱包关于同步升级 EOS 节点的公告
author: 
lang: zh
data: 2018-07-22
post_id: 46
id: 46
ref: ad
time: 
---

亲爱的派友：

比特派钱包目前正在进行 EOS 节点同步升级，部分用户 EOS 数量显示异常，这并不会影响到您的资产安全。节点同步预计24小时内完成。感谢您的理解与支持。


比特派团队<br/>
2018年07月22日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>