---
layout: post
title:  比特派钱包关于支持 HCASH 主链升级并暂停 HSR 充提的公告
author: 
lang: zh
data: 2018-08-05
post_id: 47
id: 47
ref: ad
time: 
---

亲爱的派友：

根据 HCASH 官方公告，HCASH 将于 938888 高度进行主链升级（预计时间为2018年8月8日，具体时间以区块高度为准）。比特派支持 HCASH 主链升级，并会为用户完成映射。

同时 比特派钱包 将于北京时间2018年8月6日12:00关闭 HSR 的充值和提币业务。<br/>
请注意：<span style="color:red">充提服务暂停期间请不要进行 HSR 的收发，以免造成不必要的资产损失。</span>

HCASH 主链升级完成后，比特派将更新 HSR 为 HCASH 主网资产 HC ，并开启 HC 的充值和提币业务。届时，原 HSR 的充值和提币地址将不再使用，充值到旧地址的 HSR 将无法到账。

比特派团队<br/>
2018年08月05日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>
