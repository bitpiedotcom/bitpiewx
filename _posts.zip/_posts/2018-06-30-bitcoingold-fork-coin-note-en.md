---
layout: post
title:  Notice of Suspending BTG Deposit and Withdrawal Services
author: 
lang: en
data: 2018-06-30
post_id: 42
id: 42
ref: ad
time: 
---

Dear Bitpiers,

Due to the upgrade of BTG mainnet and for the sake of your interests, Bitpie will suspend BTG deposit and withdrawals in Bitpie Wallet and Pie Bank at 13:00 on June 30, 2018(GMT+8). We will resume the deposit and withdrawal of BTG promptly after the BTG mainnet runs stably. Please pay attention to our announcement for the specific time. 

Attention:<span style="color:red"> Please do not send or receive BTG in your Bitpie wallet during the suspension of BTG deposit and withdrawals, or else you may lose your assets. </span>

Your support for Bitpie is greatly appreciated!

Bitpie Team<br/>
June 30, 2018

Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>


