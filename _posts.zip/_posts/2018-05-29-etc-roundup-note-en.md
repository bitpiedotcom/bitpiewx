---
layout: post
title:  Bitpie will Stop ETC Deposit and Withdrawals and its Sending and Receiving Services
author: 
lang: en
data: 2018-05-29
post_id: 33
id: 33
ref: ad
time: 
---

Dear Users: 

According to ETC official announcement, ETC hard fork will be carried out in the height 5,900,000. The main update of the hard fork is the remove of difficulty bomb, and it will not generate new token.

In order to protect the asset safety of users, Bitpie will stop ETC deposit and withdrawals in Pie Bank and send and receive services in Pie Wallet. After the hard fork, we will timely open ETC deposit and withdrawals and its sending and receiving services. Please find the specific time in our announcement. We apologize for any inconvenience caused by this.<br/> 

  

ETC official announcement: <a href="https://ethereumclassic.github.io/blog/2018-03-12-etc-roundup/" target="_blank" style="color:red">click</a>


Bitpie<br/>
May 30th, 2018


