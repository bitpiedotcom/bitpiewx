---
layout: post
title:  关于暂停 Zcash（ZEC）发币功能的公告
author: 
lang: zh
data: 2018-06-25
post_id: 40
id: 40
ref: ad
time: 
---

亲爱的派友：

由于 Zcash（ZEC）将于区块高度 347500 进行硬分叉(预计为香港时间2018年6月26日05:00)，为了保证平台用户利益，比特派钱包将于2018年6月25日21:00暂停 ZEC 发币功能。

派钱包将会在 Zcash（ZEC）硬分叉完成且运行稳定后，重新开放 ZEC 发币功能。

请注意，充提服务暂停期间：<span style="color:red">请不要收发 Zcash（ZEC），以免造成不必要的资产损失！</span>

感谢您对比特派 Bitpie 的支持，不便之处，敬请谅解。

比特派团队<br/>
2018年06月25日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>


