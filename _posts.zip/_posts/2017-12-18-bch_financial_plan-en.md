---
layout: post
title: Launch of Cryptocurrency Financial Product and Award Program on BCH Financial Plan
author: 
lang: en
data: 2017-12-18
post_id: 6
id: 6
ref: ad
time: 2017-12-18
---

<p class="bch-p">We are glad to announce that our first cryptocurrency financial product BCH-Financial Plan has just launched on Bitpie v2.4.1 .
</p>

<p class="bch-p">
The first financial plan is a 1-month recyclable plan for BCH. Within Piebank menu, user can find the “Financial plan” button next to BCH balance where user can click to check available plan. The basis annual interest rate for 1- month plan is 3.88%, interest will be paid by BCH.  <a href="http://docs.bitpie.com/en/latest/financialPlan/index.html" target="_blank">Click here to learn about the process</a>.
</p>

<p class="bch-p">
We will launch plans for more cryptocurrencies very soon. All plans are limited offers. Join us early before they are gone.
</p>

<p class="bch-p">
To encourage  users to experience the innovative financial program. We have an award program for early participants .
</p>


Time : 2017-12-18 12:00pm (UTC+0) - 2017-12-25 12:00pm (UTC+0）


Program details:

Invest 1-5 BCH, get 7.76% interest rate for first month.

Invest 5-10 BCH, get 11.6% interest rate for first month.

Invest 10-20 BCH, get 15.5% basic interest rate for first month. 

Invest 20-50 BCH, get 19.8% interest rate for first month.

（All interest rates are annual rates.）

Please aware of that award offers are also limited, first come first served.  

<p class="bch-p">
Early termination is available if a user has urgent need and balance will be transferred out after two business days. But in that case, all interest will be lost (both basic part and award part), please exercise caution.
</p>

<p class="bch-p">
If you are not currently a Bitpie user, please use following link to download and install Bitpie App.<br/>
Android: <a href="https://bitpie.com/andriod/" target="_blank">https://bitpie.com/andriod/</a><br/>

iOS : <a href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a><br/>
</p>
