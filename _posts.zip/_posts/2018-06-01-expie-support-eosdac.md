---
layout: post
title:  派钱包内置交易所上市 eosDAC
author: 
lang: zh
data: 2018-06-01
post_id: 38
id: 38
ref: ad
time: 
---


亲爱的用户：

Bitpie 内置交易所ExPie现已上线eosDAC，并开通 eosDAC/ETH 交易市场，邀您体验！
派银行 eosDAC 充值通道现已开放，同时派银行 eosDAC 已发放完毕，请至派银行中查看。


风险提示：数字货币是一种高风险的投资方式，请投资者谨慎购买，并注意投资风险。Bitpie 会遴选优质币种，但不对投资行为承担担保、赔偿等责任。


eosDAC 官网：<a href="https://eosdac.io/" target="_blank">https://eosdac.io/ </a>了解更多信息！
 

感谢您对比特派 Bitpie 的支持！


比特派 Bitpie 团队<br/>
2018年06月01日


Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>

