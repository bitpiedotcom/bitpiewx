---
layout: post
title: Lucky draw event on BTG/BTC exchange
author: 
lang: en
data: 2017-12-11
post_id: 5
id: 5
ref: ad
time: 2017-12-11
---

To encourage our users to experience new released in-wallet BTG/BTC exchange. Bitpie will start a lucky draw event to reward some lucky users who use BTG/BTC exchange inside Bitpie Wallet.

Event Time：2017-12-11 02:00 am – 2017-12-16 02:00 am（UTC +0）

There will be 20 winners amount users who has total trading volume between 1 BTG to 10 BTG, each will receive 0.25 BTG.

There will be 5 winners amount users who has total trading volume between 10 BTG to 50 BTG, each will receive 1 BTG.

The user who has highest trading volume during promotion time will receive 3 BTG.

<strong>Rules：</strong>

The first 5 BTG block hash values after the end of the event time will be used to do complementation for each eligible user ID, all results will be put into a ranking pool and the top-ranking users are winning users. 

The user who has highest trading volume will receive 3 BTG, no lottery will be needed.

Award BTG will be sent to user’s PieBank within 1-3 days after event time and users are free to withdraw the balance to their wallets anytime.

To participate the event, just make BTG/BTC exchange or BTC/BTG exchange within bitpie wallet. More in-wallet trading pairs will be supported very soon!

If you are not currently a Bitpie users, please use following link to download and install Bitpie App.

Android: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a>

iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>

Help:  <a class="link_app" href="http://docs.bitpie.com/en/latest/" target="_blank">http://docs.bitpie.com/en/latest/</a>

<strong>Where to participate :</strong>
<img  class="an_img" src="/img/btg_lucky_draw_img_en.png" style="display:block;margin:0 auto">
