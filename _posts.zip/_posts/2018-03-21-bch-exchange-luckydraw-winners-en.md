---
layout: post
title: BCH/BTC Trading Contest and Giveaways Winner List
author: 
lang: en
data: 2018-03-21
post_id: 14
id: 14
ref: ad
time: 
---




BCH/BTC Trading Giveaways activity time ended at 0:00 February 28th 2018(UTC+8). This activity is greatly welcomed and participated by the vast majority of community users. It is appreciated so much that we have so many participants supporting our activity, in the future we will bring more similar trading giveaway activities to reward our users.





The following is the winner list of BCH/BTC trading contest:

| UID   | prizes|   phone     |
|:-----:|:------:|:------:|
|102039 |Place to receive a two persons trip to Silicon Valley - Blockchain Exploratory (or equivalent BCH)|
|199869 |2 BCH + iPhone |1520****164|
|272390 |1 BCH + iPhone |1881****821|
|156104 |1 BCH |1527****361|
|198458 |1 BCH |1860****265|
|104614 |1 BCH |1866****510|
|259304 |1 BCH |1761****456|
|101958 |1 BCH |1860****616|
|101942 |1 BCH |1393****796|
|117398 |1 BCH |1860****360|
|140540 |0.5 BCH |**********|
|123288 |0.5 BCH |1565****298|
|253688 |0.5 BCH |**********|
|109706 |0.5 BCH |1778****379|
|181278 |0.5 BCH |1850****959|
|139579 |0.5 BCH |1860****826|
|100006 |0.5 BCH |1861****662|
|192466 |0.5 BCH |1379****961|
|170842 |0.5 BCH |1381****281|
|280913 |0.5 BCH |**********|






The following is the lucky-winner list of BCH/BTC trading giveaways:


| UID | prizes | phone|
|:-----:|:-----:|
|111711|winner will receive the top prize: A trip to Tokyo - Blockchain Exploratory (or equivalent BCH)|
|102970|1 BCH|1393****377|
|101791|1 BCH|1565****673|
|152442|0.5 BCH|1863****000|
|102211|0.5 BCH|1760****501|
|188564|0.5 BCH|1367****202|
|164759|0.5 BCH|1337****580|
|142729|0.5 BCH|1390****852|
|196713|0.5 BCH|1832****259|
|140639|0.5 BCH|1381****491|
|166321|0.5 BCH|1862****815|
|103801|0.5 BCH|1861****662|
|127911|0.5 BCH|1371****016|




<p style="color:#F46100">Award BCH will be sent to your PieBank within 24 hours and you are free to withdraw the balance to your wallet anytime.</p>

<p style="color:#F46100">Congratulations to all the winners and thanks for your support!</p>

Bitpie team

Twitter:<a href="https://twitter.com/BitpieWallet" target="_blank">https://twitter.com/BitpieWallet</a>

Facebook:<a href="https://www.facebook.com/BitpieWallet" target="_blank">https://www.facebook.com/BitpieWallet</a>


