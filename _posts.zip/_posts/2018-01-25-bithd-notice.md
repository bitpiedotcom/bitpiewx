---
layout: post
title: 比特派新品发布会 — 获奖名单公布
author: 
lang: zh
data: 2018-01-25
post_id: 8
id: 8
ref: ad
time: 
---

比特派新品发布会已圆满结束。当日为答谢各位远道而来的嘉宾支持，进行了多轮次的抽奖活动。

以下是本次活动的数字货币中奖名单：




<p style="text-align:center;color:#3ECFAF"><strong>一重礼（ 6666 BTW ）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0" style="text-align:center">

<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>231627 </td><td>chenbtc</td> <td>177****4475</td></tr> 
<tr><td>165121 </td><td>HOWYOUDOIN</td> <td>186****5750</td></tr> 
<tr><td>236630 </td><td>xiaohaibtp</td> <td>132****6464</td></tr> 

</table>






<p style="color:#F46100">恭喜以上幸运用户，每位获得 6666 BTW，奖品已经发放到您的派银行余额。</p>

<p style="text-align:center;color:#3ECFAF"><strong>二重礼 （ 1 SBTC ）</strong></p>

<table class="table" border="0" cellspacing="0" cellpadding="0">
<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>222859</td><td>zjun18</td> <td>136****8487</td></tr> 
<tr><td>101521</td><td>HuanYu-BtcOtc</td><td>182****0666</td></tr>
<tr><td>122909</td><td>f2pool-Leah</td><td>177****1282</td></tr>
<tr><td>113924</td><td>dadadada</td><td>135****4666</td></tr>
<tr><td>220831</td><td>liufei-huobi</td><td>153****5080</td></tr>
<tr><td>165121</td><td>HOWYOUDOIN</td><td>186****5750</td></tr>
</table>

<p style="color:#F46100">恭喜以上幸运用户，每位获得 1 SBTC ，奖品已经发放到您的派银行余额。
</p>
                              


<p style="text-align:center;color:#3ECFAF"><strong>三重礼 （ 10 BCD ）</strong></p>
<table class="table" border="0" cellspacing="0" cellpadding="0">

<tr><th>User ID</th><th>用户名</th><th>手机号</th></tr>
<tr><td>207107</td><td>ericgood1</td><td>136****0790</td></tr>
<tr><td>154681</td><td>sunxiaojian</td><td>136****7868</td></tr>
<tr><td>103731</td><td>easydao</td><td>185****2468</td></tr> 
<tr><td>111003</td><td>noname-964117431005</td><td>155****5050</td></tr>

</table>



<p style="color:#F46100">恭喜以上幸运用户，每位获得10 BCD ，奖品已经发放到您的派银行余额。</p>

<p style="text-align:center;color:#3ECFAF"><strong>实物中奖嘉宾：</strong></p>

<p style="text-align:center;"><strong>一等奖：iPhoneX 1个</strong></p>

<p style="text-align:center;"><strong>中奖号码：80012</strong></p>

<p style="text-align:center;"><strong>二等奖：坚果Pro 3个 </strong></p>

<p style="text-align:center;"><strong>中奖号码：80161、80079、80098</strong></p>

<p style="text-align:center;"><strong>三等奖：小米充电宝高配 10个</strong></p>

<p style="text-align:center;"><strong>中奖号码：80051、80060、80015、80026、80128、80033、80120、80155、80016、80011</strong></p>

<p style="color:#F46100">没中大奖也不要气馁，比特派送礼季才刚刚开场，请持续关注我们的微博，微信及APP内公告，很快会有更加重量级的活动在等您，大奖送不停，燃爆整个冬日。</p>

以上活动最终解释权归BITPIE LIMITED所有，如有疑问请关注微博<a href="https://weibo.com/bitpiewallet" target="_blank">@比特派社区</a>或“比特派社区”微信公众号与比特派工作人员联系。


