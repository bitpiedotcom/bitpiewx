---
layout: post
title: BTNのご送受、お預り・お引出しサービスが一時停止の通知
author: 
lang: jp
data: 2018-03-16
post_id: 13
id: 13
ref: ad
time: 
---



BTNチームは2018年3月18-19日に、BTNメインネットワークのアップグレードを実施する予定となります。そのため、アップグレード中にBTNオンチェーンの転送取引が無効と見なされることがあります。したがって、BitpieはBTNメインネットワークのアップグレードの間に以下の措置を取る予定となります：
```
1.BTNウォレットは2018年3月17日00:00からBTNサービスを停止します。BTNのアップグレード中に、ユーザーがBTNを送受信しないことを強くお勧めします。さもなければ資産が失われる可能性があります。
2.pie bankはBTNのサービス提供が2018年3月17日午前0時に停止します。復旧時間は、BTNメインネットワークのアップグレード完了時刻によって決まります。
3.ExPieのBTN取引はこのアップグレードの影響を受けず、通常取引が可能となります。

```

Official Announcement of BTN:<a href="http://www.btn.org/download/Announcement.pdf" target="_balnk" style="color:red;text-decoration:underline">http://www.btn.org/download/Announcement.pdf</a>


Bitpie団体より<br/>
2018年03月16日

