---
layout: post
title: Statement on The Airdrop of Venus Project
author: 
lang: en
data: 2017-12-6
post_id: 3
id: 3
ref: ad
time: 
---

AMT is a technical community that focuses on innovation in blockchain area. Venus is their first project which aims to create new distributed DNS service system, distributed web service system, and storage sharing system. 

Venus project team will deliver VNS to cryptocurrency community by an innovative Airdrop. The airdrop detail is as follow：

（1） BTC: VNS=1:1000<br/>
（2） ETH: VNS=1:50<br/>
（3） LTC: VNS=1:9<br/>
（4） DASH: VNS=1:65<br/>
（5） ETC: VNS=1:3<br/>
（6） XMR: VNS=1:17<br/>

As an onchain blockchain asset wallet, our users are managing their private keys by themselves. Therefore, we are not able to claim VNS on behalf of users. But we will work with project team to provide tutorials to help our users to claim VNS by themselves after the detail airdrop claiming plan is released. 

In future, Bitpie will update our wallet to support VNS.

Thanks for your support.

Bitpie Team
