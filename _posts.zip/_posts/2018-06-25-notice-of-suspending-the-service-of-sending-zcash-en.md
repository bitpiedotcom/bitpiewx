---
layout: post
title:  Notice of Suspending the Service of Sending Zcash (ZEC) 
author: 
lang: en
data: 2018-06-25
post_id: 40
id: 40
ref: ad
time: 
---

Dear Bitpiers:

Zcash (ZEC) will have a hard fork at block height 347500 at 05:00 on June 26, 2018(GMT+8). For the sake of your interests, Bitpie will suspend the service of sending Zcash (ZEC) at 21:00 June 25, 2018(GMT+8).

We will resume the sending service promptly after Zcash (ZEC) completes its hard fork and runs stably. 

Attention: Please do not deposit Zcash in your Bitpie wallet during the suspension of Zcash deposit and withdrawal, or else you may lose your assets. 

Your support for Bitpie is greatly appreciated!

Bitpie Team<br/>
June 25, 2018

Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>

