---
layout: post
title:  Supplement to the Notice of Bitpie Wallet Supporting BYTOM Blockchain Upgrade and Token Migration
author: 
lang: en
data: 2018-06-21
post_id: 39
id: 39
ref: ad
time: 
---

Fellow Bitpiers,

Bitpie and BYTOM have announced deep ecological cooperation in all aspects.<br/>
Now Pie wallet has begun the research and development of the function supporting BYTOM Blockchain Upgrade and Token Migration. Under a full understanding of the Bytom, Bitpie team has adapted to related security framework, research and development work is now moving ahead in Bitpie.

As a responsible team, we attach the greatest importance to the assets of users. We won’t launch it before we ensure the complete safety and stability of the new functions of the Pie wallet. Besides, unlike the support of regular exchanges to new tokens, if a wallet wants to provide a safe and stable support to the newly designed blockchain assets, it must carry on more comprehensive and systematic R&D work, the work includes but not limited to the development of the underlying agreement and framework of the chain and the cryptology structure. Therefore, the function of Bitpie Wallet Supporting BYTOM Blockchain Upgrade and Token Migration will be launched a bit later than expected. According to the current progress, it is expected that the function of supporting new BTM mainnet and Token Migration in 2 to 3 weeks.

What’s more, the recharging channel of BTM in Pie Bank is still open. Users can deposit the ERC20 token of BYTOM into the Pie Bank; the matching BTM mainnet assets will be sent to the users through Pie Bank in 2 to 3 weeks without any other operation. To the BTM holders that deposited BTM to Pie Bank before, Pie Bank will immediately start tokens exchange for users after the launch of BTM mainnet supporting function.

Learn more: <a href="https://bytom.io/" target="_blank">bytom.io</a>

Thanks for your support!

Bitpie Team<br/>
21st June 2018

Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>
