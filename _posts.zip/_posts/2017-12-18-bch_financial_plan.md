---
layout: post
title: 比特派送礼季之 BCH 理财活动
author: 
lang: zh
data: 2017-12-18
post_id: 6
id: 6
ref: ad
time: 2017-12-18
---

<div class="content-bch">
<p class="content-bch-h"><strong>活动时间</strong>香港时间  2017年12月18日 20：00 至 12月25日 20：00</p>

<h5 style="display:inline-block;text-align:center;margin:10px auto"><span class="bch_ads" style="background:url('/img/bch_ad.png') no-repeat;display:block;background-size:100% 100%;float:left"></span><span class="h5-bch-span">限时加息 2 - 5 倍，最高19.8%</span>
<div style="clear:both"></div>
</h5>




<p class="content-bch-p">应召广大 BCH 爱好者的迫切需求，经过昼夜不停的技术对接，比特派团队 理财产品 于香港时间12月18日上线了！</p>


<p class="content-bch-p"><strong>为庆祝新功能上线，活动期间内新用户首投当月利率翻2-5倍不等，限时限量，抢完为止。</strong></p>


<p class="content-bch-p">关注 新浪微博 <a href="https://weibo.com/bitpiewallet" target="_blank">@比特派社区</a>  评论中附带自己的比特派 用户名  + 转发置顶微博抽取21人赠送1.2个 BCH（价值15600元），其中一等奖1人赠送 0.5 BCH （价值约6500元），二等奖10人赠送 0.05 BCH（价值约650元），三等奖10人赠送 0.02 BCH（价值约260元）。</p>


<p class="content-bch-p" style="text-align:center"><strong>-------- 活动规则 --------</strong></p>

<p class="content-bch-p">下载比特派 APP v2.4.1，在派银行中参与 BCH 理财计划，流程如下：<a href="http://docs.bitpie.com/zh_CN/latest/financialPlan/index.html" target="_blank">理财流程</a></p>
<p class="content-bch-p">存币基础利率为年化 3.88% ，参与活动的用户至少投1个 BCH（上限为50个），活动期间内参与活动当月利率翻倍，投币数目越多收益越多：</p>
<p class="list-p"><span class="list-span-header"></span><span class="list-span-in">投币 1 - 5个</span>   <span class="list-span-mar">当月利率<strong>2</strong>倍</span><span class="list-span-r">年化7.76%</span><div style="clear:both"></div></p>
 <p class="list-p"><span class="list-span-header second"></span><span class="list-span-in">投币 5 - 10个</span><span class="list-span-mar">当月利率<strong>3</strong>倍</span><span class="list-span-r"> 年化11.6%</span><div style="clear:both"></div></p>
 <p class="list-p"><span class="list-span-header three"></span><span class="list-span-in">投币 10 - 20个</span> <span class="list-span-mar">当月利率<strong>4</strong>倍</span><span class="list-span-r">年化15.5%</span><div style="clear:both"></div></p>
<p  class="list-p"><span class="list-span-header four"></span><span class="list-span-in">投币 20 - 50个</span><span class="list-span-mar">当月利率<strong>5</strong>倍</span><span class="list-span-r">年化19.8%</span><div style="clear:both"></div></p>
    

<p class="content-bch-p">存币期间如需交易可在发起提币申请后两个工作日提取到账，若存币未满一个月提币将无法获得任何收益，等同于放弃活动资格，比特派提醒您谨慎操作！</p>





<p class="content-bch-info">注：在法律允许的范围内，比特派保留对本活动的最终解释权！</p>


<div class="box_1">
<div class="div_h5"><span>产品特点</span></div>
<div class="t1">
<div class="div_safe">
安全
</div>
<div class="safe_info">
<p class="safe_info_p"><strong>比特派钱包安全有保障</strong></p>
<p>比特派由比太团队开发，比太团队的“比太钱包”是首个被 <a href="https://bitcoin.org/en/wallets/desktop/windows/bither/" target="_blank">Bitcoin.org</a> 推荐的“国产”比特币钱包。</p>

</div>
</div>


<div class="t1">
<div class="div_safe">
收益
</div>
<div class="safe_info">
<p class="safe_info_p"> <strong>高净值，低风险，收益看的见</strong></p>
<p>1 BCH 可投，享受 3.88% -- 19.8% 的年化收益</p>
<p><span>注：温馨提示，投币越多收益越多，最高可享年化利率19.8%</span></p>
</div>
</div>


<div class="t1 end">
<div class="div_safe">
灵活
</div>
<div class="safe_info">
<p class="safe_info_p"> <strong>整存整取，使用更灵活</strong></p>
<p>急需交易？提取次日后到账，方便灵活</p>
<p><span>注：温馨提示，未满1个月提币将无法获得约定收益，请谨慎操作！</span></p>
</div>
</div>

</div>

<p class="content-bch-p">如果您还不是比特派用户，请在手机浏览器打开下方链接下载安装使用。</p>

<p class="content-bch-p bch-download">安卓: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a><br/>

iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>
</p>
</div>










