---
layout: post
title:  Bitpie Lists eosDAC
author: 
lang: en
data: 2018-06-01
post_id: 38
id: 38
ref: ad
time: 
---

Fellow Bitpiers,

 
eosDAC/ETH trading pairs are now available on the built-in exchange platform ExPie for trading. You can start depositing and trading eosDAC now. 


Meanwhile, eosDAC deposit and withdrawal Channel is open in Pie Bank, and Pie Bank has already finished the distribution of eosDAC, please check your eosDAC in Pie Bank.



Risk warning: cryptocurrency investment is subject to high market risk. Please make your investments cautiously. Bitpie will make best efforts to choose high quality coins, but will not be responsible for your investment losses.


Learn more: <a href="https://eosdac.io/" target="_blank">https://eosdac.io/</a>


Thanks for your support!


Bitpie Team<br/>
1th June, 2018



Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter：<a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>