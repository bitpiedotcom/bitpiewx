---
layout: post
title: Server Upgrade Notification
author: 
lang: en
data: 2018-08-08
post_id: 49
id: 49
ref: ad
time: 
---


Dear Bitpie users:

Due to the recent surge in the number of users, the visits to some regions have been slow. In order to bring you a more convenient and comfortable experience, we need to upgrade the server hardware. You will not be able to send, receive, and trade during updating from 13:00 to 14:00 (UTC+8).

Please wait patiently，thank you for your understanding and support.

Bitpie team<br/>
August 08, 2018