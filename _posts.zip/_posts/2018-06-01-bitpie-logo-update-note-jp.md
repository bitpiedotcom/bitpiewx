---
layout: post
title:  7月1日にBitpieロゴ変更のお知らせ
author: 
lang: jp
data: 2018-06-01
post_id: 37
id: 37
ref: ad
time: 
---

皆様のご支援をいただき、今までBitpieはEthereum、Bitcoin、Litecoinなどのさまざまなブロックチェーン資産の保管と取引することができるウォレットになりました。


小文字のbは、現在の製品ステータスに適していなく、そしてBitpieは単一なビットコインウォレットに間違ってしまう可能性があるので、弊社はBitpieロゴ更新することを決めました。新ロゴは2018年07月01日に変更させていただきます。<br/>
新ロゴは以下示すようになります：

<img src="/img/bitpie_logo.jpg" style="width:100%" />


新ロゴはAppleの標準サイズ仕様に従って設計され、多義語「パイ」の形状に結合し、色には安全、穏やか、テクノロジー感がある暗青色プラスシンプル、大気な白色を使用し、次第に変化する影付き、全体的なデザインは交差した線（「井」字のよう）となり、Pieウオレットの便利な入出金サービス、四通八達な分散型台帳技術理念を体現しています。<br/>
VI図は次のようになります：

<img src="/img/bitpie_v1.png" style="width:60%;display:block;margin:0 auto" />
<p style="text-align:center">図1　ハンドペイントの効果</p>
<img src="/img/bitpie_v2.png" style="width:60%;display:block;margin:0 auto" />
<p style="text-align:center">図2　パンフレットの効果</p>


Bitpieが新世代のブロックチェーンオープンプラットフォームとし、常に安全性とオープン性をコンセプトとして、ユーザー様にサービスを提供しています。


新ロゴ更新になった後、弊社関連の公式メディア公衆号、公式サイト、宣伝ページ、技術資料、社員名刺などのロゴは次第に更新されます。この期間中に、新しいロゴと古いロゴは同じ効力を持ちます。


この度は大変ご迷惑をおかけして、申し訳ございませんでした。


bitpie.com<br/>
2018年06月01日



