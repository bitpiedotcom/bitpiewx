---
layout: post
title: BCH/BTC 交易送礼活动
author: 
lang: zh
data: 2018-01-31
post_id: 10
id: 10
ref: ad
time: 
---

比特派钱包内交易所已经于1月24日正式上线，并在上线首日达到了交易所同时在线 8000 用户的惊人成绩。为了回馈广大用户的支持，比特派现开展 BCH/BTC 交易送礼活动。大奖为硅谷双人区块链考察之旅，燃爆整个春节，快来参加！


活动时间 2018年2月1日 - 2月28日

<p>奖励一：交易排名赛</p>
<p class="paragraph">活动期间在比特派钱包交易所内参与 BCH/BTC 交易的用户，将根据交易量（买入加卖出）进行排名，排名靠前者将获得奖品。</p>
<p class="paragraph">第1名：美国硅谷区块链双人考察之旅</p>
<p class="paragraph">第2名：2 BCH + iPhoneX</p>
<p class="paragraph">第3名：1 BCH + iPhoneX</p>
<p class="paragraph">第4-10名：1 BCH</p> 
<p class="paragraph">第11-20名：0.5 BCH</p>
```
剩余奖项抽奖规则：使用活动时间结束之后的第1个 BCH 区块哈希值对符合条件的用户ID进行取余进行排序。排序最靠前的用户即为中奖用户。
```



<p>奖励二：交易抽奖</p>
<p class="paragraph">活动期间在比特派钱包交易所参与 BCH/BTC 交易且交易量大于 1BCH 的用户中抽取：</p>
<p class="paragraph">一等奖1名：日本区块链双人考察之旅</p>
<p class="paragraph">二等奖2名：1 BCH</p>
<p class="paragraph">三等奖10名：0.5 BCH </p>

```
抽奖规则：一等奖: 日本区块链双人考察之旅抽奖号取 2018.2.28日北京时间 8:00 后的第一个 BTC 区块哈希值的倒数后2位字符（仅取数字部分）。
```

以上活动最终解释权归 Bitpie Limited 所有。

Bitpie Limited, Republic of Seychelles

