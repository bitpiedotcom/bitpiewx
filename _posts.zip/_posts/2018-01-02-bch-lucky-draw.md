---
layout: post
title: 2018 第一弹 BCH 一键买卖开通
author: 
lang: zh
data: 2018-01-02
post_id: 8
id: 8
ref: ad
time: 
---

<p style="text-align:center"> <strong>参与即可瓜分 BCH 大奖，更有 iPhoneX 等你来抢</strong></p>

一直以来，比特派专注于将“一键买卖”打磨成世界上易用性最强的点对点交易服务，这期间我们收到了无数用户的迫切需求，希望比特派能支持除 BTC 外更多币种的一键买卖。

BCH（比特币现金）由于其低廉的转账费用以及可靠的确认时间，短期内迅速积聚了大量的拥护者，更有大量 BCH 和 BTC 究竟哪个才是真正比特币的讨论。

So ,应召广大 BCH 拥护者的迫切需求，比特派从即日起正式开通 BCH 币种的“一键买卖”，产品上线一周内参与 买/卖 即有机会抽奖。

<strong>活动时间</strong> 2018年1月3日 --- 2018年1月10日
 
活动参与资格：活动期间累计交易 1BCH 以上 或 活动期间累计 20 个 BCH 以上；

<p> <strong>从活动期间累计 20BCH 及以上的用户中，抽取：</strong></p>

<p> <strong>一等奖  1名    奖励   1BCH + iPhoneX</strong></p>

<p> <strong>二等奖  2名    奖励   0.5BCH + iPhoneX</strong></p>

<p> <strong>从活动期间累计 1BCH 的用户中，抽取：</strong></p>

<p> <strong>三等奖  5名   奖励  0.5BCH</strong></p>

<p> <strong>四等奖  10名   奖励  0.1BCH</strong></p>

<p> <strong>五等奖  50名   奖励  0 .05BCH </strong></p>

奖励发放：BCH奖励将于活动结束后的7个工作日内发放，请获奖用户在“派银行”中查看奖励；实物礼品将与您电话沟通，请保持手机畅通。

安卓: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a>

iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>

使用帮助: <a class="link_app" href="http://docs.bitpie.com/zh_CN/latest/" target="_blank">http://docs.bitpie.com/zh_CN/latest/</a>



