---
layout: post
title: 緊急通報
author: 
lang: jp
data: 2018-03-22
post_id: 15
id: 15
ref: ad
time: 
---


アップル社は暗号通貨アプリにある程度友好していないため、今朝我々は、BitherとBitpieのiOSバージョンの開くことができない問題を発見しました。ユーザー様の資産安全を確保するために、以下のヒントにご注意ください：


<span style="color:red">１、ユーザー様の資産は安全です。既に12単語暗号、または秘密鍵を持っているユーザー様は、Android端末でBitherやBitpieをインストールして恢復することができます。</span><br/>
<span>２、12単語暗号と秘密鍵が持っていないユーザー様は、BitherとBitpieをアンインストールしないでください。只今Bitpieはアップル社に積極的に連絡しています。できるだけ早くiOSバージョンの使用権を恢復します。</span><br/>
<span>３、Android端末には影響がありません。</span><br/>


ビットパイ団体より<br/>
2018年03月22日

<style>
#content h5{
	color:red;
}
</style>
