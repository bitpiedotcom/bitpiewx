---
layout: post
title:  关于恢复 Zcash（ZEC）发币功能的公告
author: 
lang: zh
data: 2018-08-10
post_id: 51
id: 51
ref: ad
time: 
---

亲爱的派友：

Zcash（ZEC）的 Overwinter 主网升级已经完成，比特派钱包目前已经针对 Zcash 新主网完成了调试和升级，现在已经重新开放 ZEC 发币功能，请升级 App 至最新版 v3.4.6即可使用。

感谢您对比特派 Bitpie 的支持。


比特派团队<br/>
2018年08月10日