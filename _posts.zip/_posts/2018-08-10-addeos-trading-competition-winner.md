---
layout: post
title:  ADD/EOS 交易竞赛获奖名单（第一期 8月8日 - 9日）
author: 
lang: zh
data: 2018-08-10
post_id: 52
id: 52
ref: ad
time: 
---

2018 年 8 月8 日 16：00， 比特派 Bitpie 正式开通 ADD/EOS 交易对，为感谢平台用户的支持和信任，连同 ADD 同步上线交易大赛以及三重奖励，花样送好礼，详情可<a href="https://bitpie.com/2018-08-06/addeos-trading-competition-note" target="_blank" style="color:red">点击</a>了解。

<strong style="color:red">一、交易大赛赢壕礼！</strong>

其中交易竞赛活动，通过统计每日用户交易量进行排名，并发放奖励。现将第一期的交易竞赛即交易时间段为：8 月 8 日 16:00 – 9日16:00 的中奖明细公示如下：

1、每日实力排名奖：<br/>
中奖账户为：<br/>
第1名：19986＊ <br/>
第2名：25928＊ <br/> 
第3名：27239＊ <br/>
第4-10名：
19186＊,151550＊,29207＊,10195＊<br/>
10253＊,27205＊,155334＊<br/>
第11-50名：<br/>
28580＊,155382＊,35644＊,23726＊,36613＊,155367＊<br/>
36454＊,155367＊,14171＊,154763＊,155346＊,28580＊,<br/>
155382＊,35644＊,23726＊,10253＊,35644＊,36613＊,<br/>
18042＊,155367＊,36454＊,155367＊,12791＊,18387＊,<br/>
155351＊,25930＊,19932＊,10194＊,19186＊,18799＊,<br/>
28310＊,14171＊,153299＊,154763＊,37260＊,10195＊,<br/>
12791＊,25470＊,37104＊,17606＊,14237＊<br/>







奖励为：<br/>
第1名：50,000 ADD<br/>
第2名：20,000 ADD<br/>
第3名：10,000 ADD<br/>
第4-10名：每位用户 3,000 ADD<br/>
第11-50名： 每位用户500 ADD<br/>


2、每日阳光普照奖：<br/>
中奖账户为：<br/>
154259＊,13420＊,155412＊ 

中奖者均可获得100 ADD 奖励。

<strong style="color:red">二、空投奖励人人乐！</strong>

中奖账户为：<br/>
122750＊,13126＊,10176＊



<span style="color:red">恭喜中奖用户，交易活动仍在持续进行，欢迎大家前来参与！</span>

注：<br/>
温馨提示：<br/>
• 活动最终解释权归比特派 Bitpie 所有；<br/>
• 活动期间，如有恶意刷量行为，将取消参赛资格；<br/>
• 阳光奖的用户与实力奖的用户可以重叠；<br/>
• 活动结束后15个工作日内发放奖励。<br/>
• 活动排名每个工作日20:00前在 bitpie.com 官网更新展示，最终榜单活动结束后五个工作日内公布，最终榜单公布后三个工作日内无举报则按排名发放奖励。<br/>
• 数字资产是创新的投资产品，价格波动较大，请您理性判断自己的投资能力，审慎做出投资决策。<br/>
• 以上时间均为香港时间（UTC+8）。


创建账户教程：<a href="http://docs.bitpie.com/zh_CN/latest/eosaccount/index.html" target="_blank" style="color:red">点击</a><br/>
如果您在其它钱包有EOS账户，也可以导入比特派。导入教程：<a href="http://docs.bitpie.com/zh_CN/latest/privateKeyImport/index.html" target="_blank" style="color:red">点击</a>
祝您交易愉快！


比特派团队<br/>
2018年08月10日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>

