---
layout: post
title: Bitpie Wallet v3.2.0 Launched
author: 
lang: en
data: 2018-04-17
post_id: 22
id: 22
ref: ad
time: 
---


Through a long-time work, Bitpie Wallet v3.2.0 now launched! <br/>
The version added a lot of new functions and features: <br/>
```
1.Brand-new UI. 
2.More coins and tokens are supported: all ERC20 tokens, Dash, BTF (Bitcoin Faith), BTP (Bitcoin Pay), BTN (Bitcoin New), BBC (Big Bitcoin), USDT(ERC20), LCH (Litecoin Cash), SAFE, CDY (Bitcoin Candy), BTV (Bitvote), BPA (Bitcoin Pizza),
3.Pie Exchange, trading pairs including EOS/ETH, LTC/BBC, LCH/BTC, BCH/BTC, ETC/BTC, SCNY/BTC/ETH/BCH/LTC/EOS, POK/SCNY and many other fork coins, etc. 
4.Pie Bank: Financial Plan: depositing USDT with 1%-5% interests.
5.EOS public key mapping.
6.Token Factory: one click, creating your own token!
7.Supporting hardware BITHD;
8.Japanese version.
9.Other functions: Transaction memo, QR code scanning, and SBTC/BTC/BCH retrieval due to transfer to segwit addresses by mistake, and API connection of Pie Exchange (api-docs. expie.com) etc. 
```

<span style="color:red">Bitpie App is operated by Bitpie Technology (Canada) Inc. </span><br/>
Bitpie Wallet is a global leading wallet in the blockchain world. Since foundation in 2014, Bitpie has helped hundreds of thousands of users manage bitcoin assets and other cryptocurrencies. Originated from Bither team, Bitpie team is made up of blockchain professionals and business experts from IT/ Financial industries based around the world. 


Focusing on the asset safety, we put great effort on security and receive a good reputation in this respect. Therefore, our bitcoin wallet “Bither” is listed on bitcoin.org as the recommended wallet.


We provide on-chain wallet--Bitpie, off-chain cold wallet--Bither, hardware wallet—BITHD. The Open Platform(2b) is also a main direction of our strategy. 


In addition, Bitpie proposes the Partnership Program, aiming at technical consulting, blockchain-technology service, open platform, ecosystem support and international market cooperation. We welcome all corporate partners joining hands with us to engage in creating more secure and convenient blockchain use cases and make the blockchainizaiton of the world come true.<br/>
Join in us on telegram:<a href="https://t.me/BitpieInternational" target="_blank">https://t.me/BitpieInternational</a><br/>
twitter: <a href="https://twitter.com/BitpieWallet" target="_blank">https://twitter.com/BitpieWallet</a><br/>

 Any question on Bitpie is welcome there. 

