---
layout: post
title:  ADD/EOS Trading Competition Winner Lists (Day One 8th -9th Aug.)
author: 
lang: en
data: 2018-08-10
post_id: 52
id: 52
ref: ad
time: 
---

At 16:00 8th August, Bitpie listed the ADD/EOS trading pair in its built-in exchange. To extend the gratitude to our users’ trust and supports, Bitpie and ADD launched the trading competition of ADD/EOS with multiple rewards. For details, please <a href=" https://bitpie.com/2018-08-06/addeos-trading-competition-note-en
" target="_blank" style="color:red">click</a>

<strong style="color:red">I Daily Giveaway</strong>

1.Awards for largest daily trading volume. Users who participate in ADD/EOS trading in Bitpie’s built-in exchange will be ranked every 24 hours pursuant to the purchase volume (buying volume minus selling volume). The trading period is 16:00 8th -16:00 9th Aug.
The winning UIDs are:<br/>
19986＊,25928＊,27239＊,19186＊,151550＊,29207＊<br/>
10195＊,10253＊,27205＊,155334＊28580＊,155382＊<br/>
35644＊,23726＊,36613＊,155367＊<br/>
36454＊,155367＊,14171＊,154763＊,155346＊,28580＊,<br/>
155382＊,35644＊,23726＊,10253＊,35644＊,36613＊,<br/>
18042＊,155367＊,36454＊,155367＊,12791＊,18387＊,<br/>
155351＊,25930＊,19932＊,10194＊,19186＊,18799＊,<br/>
28310＊,14171＊,153299＊,154763＊,37260＊,10195＊,<br/>
12791＊,25470＊,37104＊,17606＊,14237＊<br/>



The rewards are:<br/>
Top 1: 50,000 ADD<br/>
Top 2: 20,000 ADD<br/>
Top 3: 10,000 ADD<br/>
Top 4-10: 3,000 ADD per user<br/>
Top 11-50: 500 ADD per user<br/>


2.For the FIRST 100 traders whose trading volume (24h) exceed 100 EOS, 100 ADD giveaways for every 100-EOS-equivalent volume will be awarded pursuant to their TOTAL trading volume (buying plus selling).
The winning UIDs are:<br>
154259＊,13420＊,155412＊ 

<strong style="color:red">II Airdrop to Every ADD HODLers</strong><br/>
The winning UIDs are:<br/>
122750＊,13126＊,10176＊




Congratulations to the winners! The competition is still ongoing. Welcome to join us!<br/>


Tips:<br/>
• Bitpie reserves the right to cancel or amend the Competition or Competition Rules at our sole discretion.<br/>
• Any intentional wash trading during the Competition period will not be tolerated and may result in disqualification.<br/>
• Rewards will be issued within 15 working days after the competition.<br/>
• The rankings will be updated on Bitpie.com before 20:00 (Hong Kong time) on each working day, and the final list will be published within FIVE working days after the end of the campaign. If no winners are reported within three working days after the final list is published, the list will be deemed as valid and final.<br/>
• Digital assets are innovative investment products, and their prices fluctuate greatly. Please judge your investment ability rationally and make investment decisions prudently.<br/>
• All the time above is Hong Kong Time (UTC+8).<br/>


How to Create a New EOS Account: <a href="http://docs.bitpie.com/en/latest/eosaccount/index.html" target="_blank" style="color:red">Click</a><br/>
How to Import an Existing EOS Account to Bitpie: <a href="http://docs.bitpie.com/en/latest/privateKeyImport/index.html" target="_blank" style="color:red">Click</a>


Enjoy your trading!


Bitpie Team<br/>
August 10, 2018

Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>
