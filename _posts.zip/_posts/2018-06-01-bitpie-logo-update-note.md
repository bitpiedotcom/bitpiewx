---
layout: post
title:  Bitpie 将于2018年7月1日起更换新 LOGO 通知
author: 
lang: zh
data: 2018-06-01
post_id: 37
id: 37
ref: ad
time: 
---

比特派在大家支持下成长至今，已经成为一个支持以太坊、比特币、莱特币等多种区块链资产存储及交易的钱包。


小写 b 的图标早已不再适合当前产品的现状，并且容易让大家误以为比特派只是单一比特币币种的钱包，所以我们对比特派进行 LOGO 升级。派钱包拟自2018年07月01日起正式启用新 LOGO 。<br/>
新 LOGO 展示如下：

<img src="/img/bitpie_logo.jpg" style="width:100%" />


新 logo 整体的设计按照苹果标准尺寸规范，结合异义词“pie”外形，色彩上使用代表安全稳重且具有科技感的深蓝色，外加简洁大气的白色，带以渐变跟阴影做辅助，整体以交叉线条（即：“井”）设计，体现了派钱包“通存通兑，四通八达，去中心化的开放理念”。<br/>
VI展示图如下：<br/>

<img src="/img/bitpie_v1.jpg" class="bitpie_logo_note"/>
<p style="text-align:center">图1 手绘效果</p>
<img src="/img/bitpie_v2.jpg" class="bitpie_logo_note" />
<p style="text-align:center">图2 宣传册效果</p>



作为新一代的区块链开放平台的比特派，一直秉承着安全与开放的理念为广大用户提供服务。

新 LOGO 上线后，公司相关的官方自媒体公众号、官网、宣传页、技术资料、员工名片等 LOGO 均将逐步统一更换为新版 LOGO 标识。在此期间，新标识和旧标识具有同等效力。
如因 LOGO 更换事宜给您带来不便，敬请谅解，我们将不胜感激！


bitpie.com<br/>
2018年06月01日


Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>
