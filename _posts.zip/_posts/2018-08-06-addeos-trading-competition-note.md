---
layout: post
title:  比特派钱包内交易所上线 ADD/EOS 和 CHL/EOS 交易
author: 
lang: zh
data: 2018-08-06
post_id: 48
id: 48
ref: ad
time: 
---

<h5 style="margin:0 auto;display:block;text-align:center;margin-top:10px">ADD 交易大赛公告</h5>

亲爱的派友：

比特派 Bitpie 的派银行已于2018年8月6日16:00:00（香港时间）开通 ADD 和 CHL 充值提现通道。<span style="color:red">请将比特派 APP 升级至最新版 v3.4.5 即可操作。</span>

比特派安卓版下载：<a href="https://bitpie.com/android/" target="_blank" style="color:red">点击</a><br/>
比特派苹果版：苹果用户请通过香港或美国 ID 登录 App Store 搜索（比特派或者 Bitpie）更新下载。

比特派 Bitpie 内置合作交易所 EXPIE 将于 2018年8月8日16:00:00  (香港时间)  在 EOS 交易区上线 ADD/EOS 交易对以及 CHL/EOS 交易对。

同时，比特派将于2018年8月8日16:00:00  (香港时间) 开启 ADD/EOS 交易排名赛活动，同时进行空投和充值奖励活动，联合项目方豪掷200万 ADD，回馈广大派友。


<strong>具体活动详情如下：</strong>

<span class="fontstyle">一、交易大赛赢壕礼！</span>

活动时间：香港时间2018年8月8日16:00:00至2018年8月13日16:00:00

交易大赛活动规则： 

1、每日实力排名奖：<br/>
在比特派参与 ADD/EOS 交易的用户将根据「净买入量（买入-卖出）」进行每日排名，根据排名可分别获得一下奖励：<br/>
第1名：50,000 ADD<br/>
第2名：20,000 ADD<br/>
第3名：10,000 ADD<br/>
第4-10名：每位用户 3,000 ADD<br/>
第11-50名： 每位用户500 ADD<br/>

2、每日阳光普照奖：<br/>
参与交易的用户交易量每达到100 EOS，即可获得100 ADD 奖励。例如，交易量达1200 EOS可获得1200 ADD。<br/>注：仅限交易量（买入+卖出）大于100 EOS 且排名前100的用户领取。

<span class="fontstyle">二、空投奖励人人乐！</span>

比特派钱包将在 2018 年 8 月8日 16:00:00  (香港时间) 对比特派钱包（含派银行）内所有 EOS 账户内的 ADD 进行快照，对于 ADD 持有量大于100的每个账户空投10个 ADD；

<span class="fontstyle">三、充值有礼，百万 ADD 躺着赚！</span>

比特派钱包将在 2018 年 8 月13日 16:00:00  (香港时间) 对比特派派银行内所有 EOS 账户内的 ADD「净充值（充值量-提出量）」明细进行统计，用户每净充值1000个 ADD 进派银行的，将会获得50个 ADD 奖励（活动奖励总体上限为100万个 ADD，发完为止）。

温馨提示：<br/>
•	活动最终解释权归比特派 Bitpie 所有；<br/>
•	活动期间，如有恶意刷量行为，将取消参赛资格；<br/>
•	阳光奖的用户与实力奖的用户可以重叠；<br/>
•	活动结束后15个工作日内发放奖励。<br/>
•	活动排名每个工作日20:00前在 bitpie.com 官网更新展示，最终榜单活动结束后五个工作日内公布，最终榜单公布后三个工作日内无举报则按排名发放奖励。<br/>
•	数字资产是创新的投资产品，价格波动较大，请您理性判断自己的投资能力，审慎做出投资决策。<br/>


创建账户教程：<a href="http://docs.bitpie.com/zh_CN/latest/eosaccount/index.html" target="_blank" style="color:red">点击</a><br/>
如果您在其它钱包有EOS账户，也可以导入比特派。导入教程：<a href="http://docs.bitpie.com/zh_CN/latest/privateKeyImport/index.html" target="_blank" style="color:red">点击</a>


祝您交易愉快！


<br/>
<br/>
<br/>
<br/>
<span class="fontstyle">ADD项目简介：</span>

ADD 将致力于建设基于 EOS 数据与应用生态，提供从“互联网+”到“区块链+” 的转型的数据中枢与应用平台。<br/>
数据流动、数据分析与数据存储将不可阻挡的形成跨域趋势 ，ADD 试图打造的 ADD 数据银行是基于 EOS 的全球超级计算机与超级节点的实时数据中枢与应用平台，这是一个可扩展、低延迟、高交互、并拥有可扩安全链域护栏的分布式网络平台。<br/>
在同步拥有不同链域来源的数据后，ADD 将使用自建的数据模型、数据引擎与引索机制为生态用户提供可视化、便捷的自设更细颗粒度的分析、提供专项维度与行业报告与评级体系，同时提供为用户提供一站式的去中心化应用平台级解决方案。<br/>
代币名称：ADD<br/>
空投比例：2 EOS：1 ADD<br/>
代币总量：100亿<br/>
空投数量：5亿<br/>
快照时间：2018年6月1日<br/>
空投时间：英国伦敦当地时间2018年6月22日零时起（夏令时UTC+1）<br/>
项目官网：<a href="https://eosadd.com" target="_blank">https://eosadd.com</a>

<span class="fontstyle">CHALLENGE项目简介：</span>

CHALLENGE （挑战）旨在利用区块链技术开发DAPP，通过使用代币经济和智能合约技术将任务游戏化，让人们参与积极行为。CHALLENGE DAPP将是我们首次亮相的DAPP。它的目的是激励和奖励进行锻炼并且被众人承认其保持健康的行为的玩家。CHALLENGE 代币总量为27亿个，我们将在2018年夏季以2比1的比例向EOS代币持有者空投20亿个代币。<br/>
产品：CHALLENGE DAPP<br/>
代币：CHL<br/>
空投比例：2 CHL：1 EOS<br/>
空投数量：20亿<br/>
代币总量：27亿<br/>
快照时间：2018年6月1日<br/>
空投时间：2018年7月16日<br/>
项目官网：<a href="http://challengedapp.io/" target="_blank">http://challengedapp.io/</a>


比特派 Bitpie 团队<br/>
2018年8月6日


<style>
.fontstyle{
    font-weight:400
}
</style>