---
layout: post
title: Pie Finance—USDT Financial Plan
author: 
lang: en
data: 2018-04-09
post_id: 19
id: 19
ref: ad
time: 
---



Start Time:  Apr. 10th 2018(UTC+8)<br/>
Pie Finance is a series of financial products brought by Bitpie Wallet. The previous BCH and ETH financial plan were greatly welcomed and broadly pursued by the cryptocurrency investors. Now Bitpie Wallet offers the USDT (ERC20) financial plan.


Interest accrual begins immediately after subscription. Early termination causes a deduction of earnings.<br/>
<strong>USDT Daily Plan</strong>: subject to availability; annualized interest rate:1% (on a daily basis, withdrawal on demand)

<strong>USDT Monthly Plan</strong>: subject to availability; annualized interest rate:5% (on a monthly basis)


<strong>How to Subscribe</strong><br/>
Install Bitpie App v3.1.7, select USDT “financial plan” in Pie Bank. <br/>
Subscribing tutorial: <a href="http://docs.bitpie.com/en/latest/financialPlan/index.html" target="_blank">click</a><br/>
Threshold: 100USDT, single-account upper limit: 100,000USDT

<strong>How to Withdraw</strong><br/>
Withdrawal amount will be due within two workdays on demand.<br/>
No earnings to unsubscribing within one month.<br/>
(Bitpie reserves the right to final interpretation of this activity.)<br/>


<strong>More about Pie Finance</strong><br/>
<strong>Safety</strong><br/>
Bitpie Wallet is developed by Bither team, who is also the developer of Bither Wallet, the first “Chinese” bitcoin wallet recommended officially by bitcoin.org. Bither team specializes in developing safe wallet and protecting your blockchain assets.<br/>
<strong>Flexibility</strong><br/>
Pie Finance provides diversified options including day-to-day deposit and fixed period deposit. Withdrawn amounts will be due within two workdays allowing transactions not being influenced.<br/>
<strong>Profitability</strong><br/>
Pie Finance is featured by low risk and moderate rate of return. It allows you increase gross assets on a predictable and stable basis.<br/>


Pie Finance--Making equal, simple and credible financial service available to every user!


