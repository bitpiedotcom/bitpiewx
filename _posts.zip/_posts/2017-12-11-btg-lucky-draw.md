---
layout: post
title: 比特派送礼季 – BTC/BTG币币兑换抽奖派送活动
author: 
lang: zh
data: 2017-12-11
post_id: 5
id: 5
ref: ad
time: 2017-12-11
---

因用户踊跃要求，比特派 BTG 送礼活动加奖了！活动时间内在比特派内进行 BTG - BTC 币币兑换，无论哪个兑换方向，都有机会抽取惊喜大奖！

活动时间：2017年12月11号早上10点 – 2017年12月16号早上10点（香港时间）

<strong>活动期间参与 BTG 快捷币币交易：</strong>

总交易量 1 - 10 BTG  的用户，抽取20名幸运用户,每位赠 0.25 BTG。

总交易量 10 - 50 BTG 的用户，抽取5名幸运用户,每位赠 1 BTG。

总交易量最高的用户，赠送3 BTG。

<strong>抽奖规则：</strong>

使用活动时间结束之后的前5个 BTG 区块哈希值对符合条件的用户ID进行取余进行排序。排序最靠前的用户即为中奖用户。总交易量最高的用户无需抽奖，直接获得3 BTG 大奖！

赠送的奖品 BTG 将在活动结束后1-3天内发放致派银行余额。

本活动无需报名，活动时间内在比特派 APP 内进行 BTG 币币兑换即可参与。其他币种的币币兑换也会陆续开放，敬请关注！

如果您还不是比特派用户，请在手机浏览器打开下方链接下载安装使用。

安卓: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a>

iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>

使用帮助: <a class="link_app" href="http://docs.bitpie.com/zh_CN/latest/" target="_blank">http://docs.bitpie.com/zh_CN/latest/</a>

<strong>APP内活动参与路径：</strong>

<img  class="an_img" src="/img/btg_lucky_draw_img.png" style="margin:0 auto;display:block">





