---
layout: post
title:  ADD/EOS Trading Competition Has Finished Successfully
author: 
lang: en
data: 2018-08-20
post_id: 53
id: 53
ref: ad
time: 
---

Dear Bitpiers:

ADD/EOS trading competition on Bitpie’s built-in exchange, which was launched at 16:00:00 on August 8, 2018 (Hong Kong time), has finished successfully. Thanks a lot for your support and participation.

For details about the ADD/EOS trading competition, please:<a href="https://medium.com/@Bitpie/bitpie-built-in-exchange-lists-add-eos-and-chl-eos-trading-pairs-add-eos-trading-competition-ffc86b5feada
" target="_blank">click</a><br/>

For winners lists, please click:<br/>
Day one:<a href="https://medium.com/@Bitpie/add-eos-trading-competition-winner-lists-day-one-8th-9th-aug-12579c971358" target="_blank">click</a><br/>
Day two:<a href="https://medium.com/@Bitpie/add-eos-trading-competition-winner-lists-day-two-9th-10th-aug-4ff3e39fbad7" target="_blank">click</a><br/>
Day three:<a href="https://medium.com/@Bitpie/add-eos-trading-competition-winner-lists-day-three-10th-11th-aug-cc1b649d2407" target="_blank">click</a><br/>
Day four:<a href="https://medium.com/@Bitpie/add-eos-trading-competition-winner-lists-day-four-11th-12th-aug-dbe098f98140" target="_blank">click</a><br/>
Day five:<a href="https://medium.com/@Bitpie/add-eos-trading-competition-winner-lists-day-five-12th-13th-aug-ca7bd0e1fc7a" target="_blank">click</a><br/>

To extend the gratitude to our users’ trust and supports, Bitpie and ADD launched the trading competition of ADD/EOS with multiple rewards. Bitpie will launch more activities like this to benefit the users.

Thanks for your supports again.

Bitpie Team<br/>
August 20, 2018

Find us on<br/>
Telegram:<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter:<a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a><br/>
Medium:<a href="https://medium.com/@Bitpie" target="_blank">medium.com/@Bitpie</a>


