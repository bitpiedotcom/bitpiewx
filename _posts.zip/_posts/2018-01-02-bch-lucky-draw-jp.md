---
layout: post
title: 2018第一弾BCH簡単取引公開
author: 
lang: jp
data: 2018-01-02
post_id: 8
id: 8
ref: ad
time: 
---

参加するだけで大量プレゼントを、さらにiPhoneXもあなたを待っています
ずっと前から、ビットパイは『簡単取引』に専念し、それを世界中に最も使いやすいP２P取引サービスに磨いています。この期間で我々は数え切れないユーザー様から、ビットパイがBTC以外にも、他の仮想通貨を支持できる需要をいただきました


BCH（ビットコインキャッシュ）は安い振込手数料と早い確認時間で、短期的に多い擁護者が集まり、さらにBCHとBTCいったいどれが本物のビットコインかの議論が屡々あります

So、大勢のおもむく所に順応、ビットパイは今日からBCHの簡単取引サービスを開通しました。開通した一週間内で売買すると抽選キャンペーンが参加できます。

キャンペーン期間　2018年1月3日 — 2018年1月10日

キャンペーンに参加する資格：期間内累計取引量が20BCHもしくは１BCH以上：
```
期間内累計取引量が20BCH以上のユーザー様から抽選で：
一等賞  1名様    賞品   1BCH + iPhoneX
二等賞  2名様   賞品   0.5BCH + iPhoneX

期間内累計取引量が20BCH以上のユーザー様から抽選で：
三等賞  5名様   賞品  0.5BCH
四等賞  10名様  賞品  0.1BCH
五等賞  50名様  賞品  0 .05BCH
```


賞品の発送について：BCH賞品は7営業日以内に発送します、当選者のユーザー様は『パイ銀行』でチェックしてお願い致します。実物プレゼントの発送は電話確認が必要となります。電話に出られるようお願いします。



アンドロイド: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a>

iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>

ヘルプ:  <a class="link_app" href="http://docs.bitpie.com/en/latest/" target="_blank">http://docs.bitpie.com/en/latest/</a>