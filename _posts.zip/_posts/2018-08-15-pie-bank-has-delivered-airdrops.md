---
layout: post
title:  “派银行” 已发放 ADD、CHL、IQ、EOX、HORUS、BLACK、EDNA 空投
author: 
lang: zh
data: 2018-08-15
post_id: 54
id: 54
ref: ad
time: 
---

亲爱的派友：

比特派 Bitpie 钱包的 “派银行”已经为 EOS 持有者发放 ADD、CHL、IQ、EOX、HORUS、BLACK、EDNA 七个基于EOS主网的币种的空投。

以下是 此次空投具体情况的介绍：

<table class="table table-content" border="0" cellspacing="0" cellpadding="0">
<tr><th>代币名称 </th><th>快照时间</th><th> 空投比例</th><th> 官方空投总量</th><th>发行总量</th><th>官方网站</th></tr>
<tr><td>IQ</td><td>创世区块</td> <td> 5.1IQ:1EOS </td><td>51亿</td><td> 100亿 </td><td><a href="https://everipedia.org/" target="_blank">https://everipedia.org/</a></td></tr> 
<tr><td>ADD</td><td>创世区块</td> <td> 0.5ADD:1EOS </td><td>5亿</td><td> 100亿 </td><td><a href="https://eosadd.com/" target="_blank">https://eosadd.com/</a></td></tr> 
<tr><td>EOX</td><td>创世区块</td> <td> 1EOX:1EOS </td><td>9亿</td><td> 100亿 </td><td><a href="https://www.eoxlab.io/" target="_blank">https://www.eoxlab.io</a></td></tr>
<tr><td>HORUS</td><td>创世区块</td> <td> 1HORUS:1EOS </td><td>9亿</td><td> 12亿 </td><td><a href="http://www.horuspay.io" target="_blank">http://www.horuspay.io</a></td></tr>
<tr><td>CHL</td><td>创世区块</td> <td> 2CHL:1EOS </td><td>20亿</td><td> 27亿 </td><td><a href="http://challengedapp.io/" target="_blank">http://challengedapp.io/</a></td></tr>
<tr><td>BLACK</td><td>创世区块</td> <td>1BLACK:1EOS </td><td>9亿</td><td> 30亿 </td><td><a href="https://eosblack.io/" target="_blank">https://eosblack.io/</a></td></tr>
<tr><td>EDNA</td><td>创世区块</td> <td>1EDNA:1EOS </td><td>10亿</td><td> 13亿 </td><td><a href="https://edna.life/" target="_blank">https://edna.life/</a></td></tr>
<tr><td colspan="6">注：创世区块时间为 2018年 6 ⽉ 3 ⽇ 7 时（UTC+8）</td></tr>
</table>


注：本公告仅摘录基本项目信息供大家参考，不代表比特派Bitpie官方意见，且不构成任何投资建议

感谢您一直以来的支持，比特派Bitpie将继续竭诚为您提供更加优质的服务。

比特派团队<br/>
2018年08月15日

Bitpie 社群：<br/>
新浪微博：@比特派钱包 <a href="https://weibo.com/bitpiewallet" target="_blank">weibo.com/bitpiewallet</a><br/>
微信公众号：公众号搜索“比特派钱包”<br/>
Telegram：<a href="https://t.me/bitpie1" target="_blank">t.me/bitpie1</a>

<style>
.content-p{
width:70%;
}
@media(max-width:768px){
.content-p{
overflow-x:auto;
}
.table-content{
    width:700px;
}
}
</style>



