---
layout: post
title:  bitpieがETCに関する受送信機能を一時停止しました
author: 
lang: jp
data: 2018-05-29
post_id: 33
id: 33
ref: ad
time: 
---


ユーザー様へ：


ETCの公式ニュースによると、ETCはブロックチェーン高さ5,900,000でハードフォークされます。今回のハードフォークがディフィカルティボムを移除するため、新しい通貨は生成されません。


ユーザー様の資産安全を確保するため、BitpieがPie BankのETC入出金とPieウォレットのETC受送信サービスを一時停止しました。ETCハードフォークが安定した後、できる限り早めにサービスを再開いたします。具体的な時間には、公告で発表させて頂きます。この度は大変ご迷惑をお掛けして申し訳ございません。


ETC公式ニュース：<a href="https://ethereumclassic.github.io/blog/2018-03-12-etc-roundup/" target="_blank" style="color:red">クリック</a>


Bitpieチームより<br/>
2018年05月29日



