---
layout: posts
title: "Bitpie + ETH"
author: "Wenhao"
lang: "en"
ref: eth
---

![eth image](/image/ethen.png "Bitpie")

Bitpie Team

2017-9-6

