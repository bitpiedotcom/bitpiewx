---
layout: post
title:  Notice of Resumption of BTG Deposit and Withdrawal
author: 
lang: en
data: 2018-07-09
post_id: 43
id: 43
ref: ad
time: 
---


Dear Bitpiers,

The upgrade of BTG mainnet has been finished and Bitpie has resumed BTG deposit and withdrawals in Bitpie Wallet and Pie Bank.

Thanks a lot for your understanding and support. 

Bitpie Team<br/>
July 9, 2018

Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter： <a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>

