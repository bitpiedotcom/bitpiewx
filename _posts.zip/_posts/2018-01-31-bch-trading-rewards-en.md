---
layout: post
title: BCH Trading Competition and Lucky Draw 
author: 
lang: en
data: 2018-01-30
post_id: 10
id: 10
ref: ad
time: 
---

Event Time:  Feb.1st – Feb 28th 2018

Bitpie in-wallet exchange went live since V3.0.0. The in-wallet exchange has gained extraordinary popularity in our users and reached 8,000 peak concurrent users at very first day.


To reward our supporters and encourage more users to experience the in-wallet exchange, we have compiled some amazing prizes for our users to win in the BCH trading competition. We will rank users from 1 to 20 in terms of the total BCH volume traded on your account (includes both buys & sells) in the BCH/BTC trading pair during the competition period. The reward program will be as follows:


<p class="paragraph">1st Place to receive a two persons trip to Silicon Valley - Blockchain Exploratory (or equivalent BCH)</p>
<p class="paragraph">2nd Place to receive 2 BCH and an iPhoneX </p>
<p class="paragraph">3rd Place to receive 1 BCH and an iPhoneX </p>
<p class="paragraph">4th - 10th Place: each to receive 1 BCH</p>
<p class="paragraph">11th - 20th Place: each to receive 0.5 BCH</p>


All users who has more than 1 BCH volume traded (includes both Buys & Sells) in the BCH/BTC trading pair during the event period are eligible for a lucky draw. The reward program will be as follows:



<p class="paragraph">10 lucky users will receive 0.5 BCH. </p>
<p class="paragraph">2 lucky users will receive 1BCH.</p>
<p class="paragraph">1 winner will receive the top prize: A trip to Tokyo - Blockchain Exploratory (or equivalent BCH)</p>

<p>Note:</p>
<p class="paragraph">Bitpie reserves the right to cancel or amend the competition or competition Rules and the lucky draw rules at our sole discretion. All trades that we deem to be “wash trades” will not count towards your total trading volume for this trading competition.
</p>
 
Bitpie Limited, Republic of Seychelles


