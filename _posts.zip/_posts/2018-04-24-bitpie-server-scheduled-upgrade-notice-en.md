---
layout: post
title: Server Upgrade Notification (April 24, 2018)
author: 
lang: en
data: 2018-04-24
post_id: 24
id: 24
ref: ad
time: 
---

Dear users,<br/>
Due to the surge of our user volume recently, slow access to the server occurred in some areas. In order to provide better service quality and trading experience, Bitpie will perform server upgrade from 0:00-1:00a.m., April 25th, 2018 (UTC+8). During the upgrade, wallet function will not be accessible and the trading will be suspended.


We apologize for any inconvenience this upgrade may cause and appreciate your support and understanding.


Bitpie Team
