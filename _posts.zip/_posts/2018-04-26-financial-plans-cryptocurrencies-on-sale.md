---
layout: post
title: 六大币种，理财全开
author: 
lang: zh
data: 2018-04-26
post_id: 24
id: 24
ref: ad
time: 
---

<div class="content-bch" >
<p style="text-align:left !important;line-height:16px;padding-top:10">开售时间： 香港时间  2018年04月26日 20：00</p>

<p style="text-align:left;line-height:16px;padding-top:10">比特派六大币种理财全开提供定期&活期理财！</p>

<p style="text-align:left;line-height:16px;padding-top:10"><strong>买入即刻计息，若未到期提现将损失利息</strong></p>
<p style="text-align:left;line-height:16px;padding-top:0"><strong>日产品：</strong>额度有限售完为止（按天计算，提现自由）</p>
<p style="text-align:left;line-height:16px;padding-top:0"><strong>月产品：</strong>额度有限售完为止（按整月计算，回报率高）</p>

<table style="margin-top:20px" class="bch-post">
<tr><th>币种</th><th>最小参投数量</th><th>单账户上限</th><th>日产品年化利率</th><th>月产品年化利率</th></tr>
<tr><td>BTC</td><td>0.2</td><td>2</td><td>1%</td><td>3.88%</td></tr>
<tr><td>BCH</td><td>1</td><td>10</td><td>1%</td><td>3.88%</td></tr>
<tr><td>ETH</td><td>2</td><td>20</td><td>1%</td><td>3.88%</td></tr>
<tr><td>LTC</td><td>10</td><td>100</td><td>1%</td><td>3.88%</td></tr>
<tr><td>EOS</td><td>100</td><td>1000</td><td>1%</td><td>3.88%</td></tr>
<tr><td>SCNY</td><td>10,000</td><td>100,000</td><td>1%</td><td>5.0%</td></tr>



</table>


<p class="content-bch-p">
<strong >购买理财</strong><br/>
	下载比特派 ，在派银行中参与理财计划，流程如下：<a href="http://docs.bitpie.com/zh_CN/latest/financialPlan/index.html" target="_blank">理财流程</a></p>
    

<p class="content-bch-p">
	<strong>理财产品提现</strong><br/>存币期间如需交易可在发起提币申请后两个工作日提取到账，若存币未满一个月提币将无法获得任何收益，等同于放弃活动资格，比特派提醒您谨慎操作！</p>





<p class="content-bch-info">注：在法律允许的范围内，比特派保留对本活动的最终解释权！</p>


<div class="box_1">
<div class="div_h5"><span>产品特点</span></div>
<div class="t1">
<div class="div_safe">
安全
</div>
<div class="safe_info">
<p class="safe_info_p"><strong>比特派钱包安全有保障</strong></p>
<p>比特派由比太团队开发，比太团队的“比太钱包”是首个被 <a href="https://bitcoin.org/en/wallets/desktop/windows/bither/" target="_blank">Bitcoin.org</a> 推荐的“国产”比特币钱包。</p>

</div>
</div>


<div class="t1">
<div class="div_safe">
收益
</div>
<div class="safe_info">
<p class="safe_info_p"> <strong>高净值，低风险，收益看的见</strong></p>
<p>为用户提供低风险、收益率适中的理财服务，帮助用户实现稳健的、可预期的资产增值</p>

</div>
</div>


<div class="t1 end">
<div class="div_safe">
灵活
</div>
<div class="safe_info">
<p class="safe_info_p"> <strong>整存整取，使用更灵活</strong></p>
<p>根据您的实际需求自由选择活期、定期理财，快捷理财的同时获得相应利息，提币申请后两个工作日内到账，不因理财影响交易。
</p>

</div>
</div>

</div>

<p class="content-bch-p">如果您还不是比特派用户，请在手机浏览器打开下方链接下载安装使用。</p>

<p class="content-bch-p bch-download">安卓: <a class="link_app android" href="https://bitpie.com/android/" target="_blank">https://bitpie.com/andriod/</a><br/>
iOS : <a class="link_app ios" href="https://bitpie.com/ios/" target="_blank">https://bitpie.com/ios/</a>
</p>
</div>
