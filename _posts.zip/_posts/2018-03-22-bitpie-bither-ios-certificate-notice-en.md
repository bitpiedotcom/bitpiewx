---
layout: post
title: Urgent notification about app access on IOS device
author: 
lang: en
data: 2018-03-22
post_id: 15
id: 15
ref: ad
time: 
---



Since now Apple Inc. is not friendly to cryptocurrencies, this morning we found Bitpie App iOS version and Bither App iOS version cannot be opened. Therefore, we are notifying you the following information so as to ensure your assets safety.


1.All users’ assets are safe. If you have saved the seed or private key, you can install Bitpie or Bither apps in an android device and recover your wallet.<br/>
<span style="color:red">2.If you are not sure if the seed or private key were backed up correctly, please DO NOT uninstall app and wait for further notification.</span> <br/>
3.Users with Android devices are not influenced.<br>



Now we are actively dealing with Apple Inc. to re-enable the iOS version access A.S.A.P. Please wait patiently. Your support is highly appreciated.




Bitpie Team<br/>
22nd March, 2018


<style>
#content h5{
	color:red;
}
</style>
