---
layout: post
title:  Notice of Bitpie LOGO change in 1st July, 2018
author: 
lang: en
data: 2018-06-01
post_id: 37
id: 37
ref: ad
time: 
---

With your support and encouragement, Bitpie has now become a wallet that supports the storing and trading of multiple blockchain assets such as Ethereum, Bitcoin and Litecoin.


The logo with a lowercase letter "b" is not suitable for our current products, and it may result in a misunderstanding that Bitpie is a wallet just for Bitcoin, so we have upgraded the Bitpie logo.  
Pie wallet will start to use new Logo in 1st July 2018. <br/>
Here is our new LOGO:  

<img src="/img/bitpie_logo.jpg" style="width:100%" />


Our new logo is designed to the specification of Apple standard size, combined with the appearance of homonym “pie”. In color design, we have chosen dark blue which symbolizes security and high tech, combined with a simple white, added with gradients and shades. The overall design of the logo uses cross lines(looks like a Chinese word: ''井'') which represent Pie wallet's idea of ''free deposit and withdrawal, extending in all directions and decentralization''.<br/>
Here are our VI pictures:

<img src="/img/bitpie_v1.png" style="width:60%;display:block;margin:0 auto" />
<p style="text-align:center">Pic 1 hand drawn sketch effect</p>
<img src="/img/bitpie_v2.png" style="width:60%;display:block;margin:0 auto" />
<p style="text-align:center">Pic 2 brochure effect</p>


Bitpie, as a new blockchain opening platform, has been committed to providing services for users with the idea of security and openness.


After the launch of our new LOGO, we will gradually change our LOGO into the new version in related official we media accounts, official websites, flyers, technical data, business card of employees, etc. During this period, both logos have equal legal force.


We apologize for any inconvenience this might have caused you and appreciate your understanding.


bitpie.com<br/>
1st Jun 2018



Find us on<br/>
Telegram：<a href="https://t.me/BitpieInternational" target="_blank">t.me/BitpieInternational</a><br/>
Twitter：<a href="https://twitter.com/BitpieWallet" target="_blank">twitter.com/BitpieWallet</a>



