---
layout: post
title: Announcement of Suspension on BTN Transfer, Deposit and Withdrawal
author: 
lang: en
data: 2018-03-16
post_id: 13
id: 13
ref: ad
time: 
---



BTN team will upgrade the mainnet on 18th-19th March, 2018, the upgrade duration might result in the invalidity of on-chain transferring. Therefore, Bitpie will take the following measures during the upgrade:
```
1.BTN wallet will suspend the transfer service from 0:00a.m. 17th March, 2018. It is strongly 
recommended that not to transfer BTN; otherwise you may encounter the loss of assets.
2.Pie Bank will suspend the deposit and withdrawal service from 0:00a.m. 17th March, 2018. The resumption time depends on the time when the BTN mainnet upgrade completes.
3.BTN in ExPie will not be affected on trading.

```

Official Announcement of BTN:<a href="http://www.btn.org/download/Announcement.pdf" target="_balnk" style="color:red;text-decoration:underline">http://www.btn.org/download/Announcement.pdf</a>


Bitpie Team<br/>
17th March 2018


