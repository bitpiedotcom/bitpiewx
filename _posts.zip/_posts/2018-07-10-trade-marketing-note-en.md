---
layout: post
title:  Notice of Bitpie Closing Instant Trade Service
author: 
lang: en
data: 2018-07-10
post_id: 45
id: 45
ref: ad
time: 
---


Dear Bitpiers:

Bitpie will upgrade the framework of instant trade service from now, therefore we will close instant trade service (while users can still sell SCNY). After upgrade, the difference in selling and buying price will be greatly reduced, and the trade service fees will also be reduced sharply, the users’ experience on instant trade service will be improved, and we will provide more comprehensive KYC strategy to ensure the security of users’ assets. The upgrade will take about 3 weeks, we will inform you as soon as possible when we resume the service.

We apologize for any inconvenience caused by this. Thank you for your understanding.

Bitpie team<br/>
10th July, 2018


